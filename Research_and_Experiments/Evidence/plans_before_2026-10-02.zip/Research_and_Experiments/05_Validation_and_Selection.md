# Validation and final selection

This is a proposed protocol, not a description of completed model tests. Lock its task-specific choices before running comparisons.

**Parallel-experiment update, 28 September:** Use [the full schedule](10_All_Experiments_Parallel_Schedule.md) for all 30 plans and additional feature/RL comparisons. Each task keeps its own frozen data contract. Parallel workers share immutable split/configuration versions and write separate run outputs. Log the number of exploratory comparisons, reserve final data before launching them, and independently confirm selected gains. Parallel work does not relax any validation requirement below.

## Keep three kinds of confidence separate

| Kind | Meaning | Present status |
|---|---|---|
| Source confidence | We verified what the source or file says | High for live rules and direct metadata counts; access limits elsewhere are in the library |
| Experiment value | The test can change a meaningful decision | High for independence, baselines, subgroup failures, and reproduction |
| Outcome confidence | Our method actually improves the intended task | Unmeasured until controlled runs and confirmation exist |

Do not assign a percentage chance of winning. There is no calibrated model of judging outcomes here. An experiment can be valuable even when it rejects the preferred method.

## Freeze the data contract

1. Define the target, input information available at use time, physical sample unit, and exact claim.
2. Inventory IDs, labels, duplicates, acquisition groups, data/weight versions, and rights.
3. Save a primary final holdout before training. Keep its predictions and errors out of model selection.
4. Use only development groups for architecture, augmentation, crop, early stopping, and threshold choices.
5. Fit probability calibration on separate groups or with documented group-aware cross-fitting. Do not measure a calibrator's success on the data used to fit it.
6. Record every learned transformation, including imputation, normalization, feature selection, dimensionality reduction, and any reference retrieval index. Fit them on training data only unless explicitly reporting a different, transductive protocol.

Reading public labels to audit splits is not the same as tuning on test predictions. Once the split is frozen, do not repeatedly inspect its errors to improve the model.

### Route A: real-chip quality

The original image folders are not proof of independent chips. Verify actual chip/run IDs if available. If valid groups are obtained, define a grouped train/development/test partition before any model training, retaining original folder assignments as metadata.

If only filename prefixes are available, use them as a **proxy-group sensitivity test** and explicitly limit the claim. Grouping by an unverified prefix does not establish new-chip or new-lab performance. Do not relabel prefixes as chip IDs.

Choose one primary final protocol. Do not also train a published-split reproduction model on images reserved by the primary grouped holdout, then use its results to choose the candidate. All development comparisons, including optional random-image versus group-split diagnostics, must stay inside the primary development pool. A reported paper score can remain a noncomparable literature reference.

Target split sizes are secondary to preserving group independence and class support. Start with roughly 70/15/15 only if group counts allow it; otherwise document a justified grouped design. Never break groups to hit exact percentages. Check that training contains both target labels and report unsupported validation slices.

### Route B: nucleus analysis

Use BBBC039's published partitions. Keep all crops and augmented versions of each original image together. Group resampling by the highest known source unit; if only image identity is available, state that limitation.

A pretrained model that may have seen evaluation images is not a clean independent benchmark. Either verify exclusion, use a fresh eligible test set, or report it separately as exploratory. BBBC038 must pass both dataset-overlap and pretraining-exposure checks before an independence claim.

## Route A metrics

Map bad to positive label 1 in the evaluation code, even though the spreadsheet stores bad as decision 2. Verify this mapping against the archive folders.

| Metric | Definition and use |
|---|---|
| Balanced accuracy | Mean of bad recall and good recall; report both recalls too |
| Bad-class average precision | Ranking summary for finding bad samples; report bad prevalence alongside it |
| False-pass rate | Bad samples predicted good divided by all bad samples, at a threshold selected on development data |
| Brier score | Mean squared difference between predicted bad probability and the 0/1 label |
| Log loss | Probability penalty for wrong/confident predictions; lower is better |
| Queue catch rate | Bad samples in the review queue divided by all bad samples |
| Residual bad rate | Bad samples outside the queue divided by all samples outside the queue |
| Runtime | Measured preprocessing and inference seconds/image on a named machine |

Always show confusion-matrix counts and sample/group counts. If a slice has no positives or no negatives, label the corresponding metric unavailable and show why. Never average away a required missing or failing group.

### Review-budget comparison

Use 20% reviewed images as the proposed primary workload, with 10% and 30% secondary. These are design choices, not organizer requirements or scientifically established optimum values.

Rank each method's same evaluation images, select the same number for review, and apply a deterministic tie rule. This is a batch-ranking workflow using unlabeled incoming scores. If the product instead needs a fixed probability threshold, freeze that threshold on calibration/development data and report the actual resulting test coverage.

Compare random review, an image-quality rule, predicted bad probability, and the proposed enhanced score. Report random-review variability. An uncertainty score must beat the simple bad-probability queue to justify added complexity.

Also report classification error on all inputs. Do not advertise low residual error after removing nearly all images. No queue analysis establishes human review speed without a timed study.

## Route B metrics

- **Count MAE:** mean absolute difference between predicted and reference object counts.
- **Signed count bias:** mean predicted count minus reference count; reveals systematic under/overcounting.
- **Object F1 at IoU 0.5:** match objects one-to-one using only pairs meeting the threshold. Use a deterministic maximum-cardinality matching, breaking ties by total overlap. F1 = `2 TP / (2 TP + FP + FN)`.
- **Mean per-image F1 and pooled object F1:** report separately; they weight images differently.
- **Merge/split and missed-object errors:** inspect failure patterns, not just foreground overlap.
- **Seconds/image and memory:** use the original image size and named hardware.

IoU is overlap area divided by union area. The 0.5 threshold is our proposed metric setting, not an AI4S judging metric. Fix it before comparisons. Where both prediction and reference contain no objects, define object F1 as 1; if only one is empty, define it as 0. Check these conventions in the evaluator.

Do not use relative count error when the reference count is zero. For warning tests, a proposed large-error threshold is `absolute error >= max(5 nuclei, 10% of reference count)`. Validate its practical meaning with the intended user, and lock it before evaluation. Until then, it is a planning assumption.

## Make uncertainty meaningful

- Use paired comparisons: candidate and baseline predict the same examples under the same split and measurement code.
- Bootstrap whole confirmed independent groups, keeping every member together. A proposed setting is 2,000 resamples with a recorded seed and a 95% interval for the paired difference.
- If independence is only supported at image or proxy-prefix level, state that the interval has that limitation. A large number of nuclei does not imply the same number of independent experiments.
- Report each training seed and its paired difference. Repeated seeds on one test set are not independent biological replications.
- Small groups produce uncertain estimates. Show the denominators and interval rather than turning a wide interval into high confidence.
- Predeclare one primary comparison per decision stage. Many exploratory comparisons followed by a narrow interval are not a confirmatory result. Confirm the chosen candidate on fresh held-out groups or a locked final test.

## Promotion and stop rules

The following practical margins are **proposed planning assumptions**. Replace them with justified user/task requirements before the first comparison and record the change. Never move them after seeing final-test results.

| Decision | Proposed minimum practical benefit | Other required conditions |
|---|---|---|
| Better chip classifier | At least 2 percentage points higher balanced accuracy | Paired evidence supports improvement; no more than 2 points loss in any sufficiently supported required cell-type bad recall |
| Better review queue | At least 5 percentage points more bad cases caught at 20% review | Supported paired gain; no catastrophic subgroup failure; same inputs and workload |
| Better nucleus method | At least 10% relative reduction in count MAE | Supported paired gain; object F1 and required groups do not materially worsen |
| Useful simpler method | Similar task performance within a predeclared tolerance with materially lower measured effort/runtime | No hidden loss in a required group; no claim of higher accuracy |
| Better calibration | Improved held-out proper scores and useful reliability assessment | No claim that scaling alone improved binary ranking; shift performance reported |

Do not apply a relative gain rule to a baseline already at zero error. If the sample is too small to support a clear improvement, label the result inconclusive. A practical gain and an uncertainty interval answer different questions; report both.

For each selected method, show its results by cell type, acquisition group where known, clean/stress distribution, and enabled/disabled review guard. Include the worst examples. A required group at or near zero must reopen selection, irrespective of the overall mean. A fallback or guard must be validated on held-out failures, not merely suggested.

If two controlled attempts fail to resolve a route's main limitation, stop cosmetic tuning. Revisit data/target validity or try a structurally different approach. Keep the simple baseline and every negative result.

## Final decision ledger

Complete this before the submission action. All fields are pending until experiments run.

| Item | Required evidence | Current status |
|---|---|---|
| Chosen task and category | One real user need, exact endpoint, honest scope | Conditional proposal only |
| Chosen method | Saved candidate and strongest-baseline predictions | Unmeasured |
| Decisive gain | Paired result, practical margin, independent confirmation | Unmeasured |
| Worst-case survival | Per-group/distribution failures and tested guard or narrower scope | Unmeasured |
| Original contribution | Comparison showing what our new work adds | Proposed |
| Rights and overlap | Exact inputs/weights and documented resolutions | OOC discrepancy and model checks open |
| Reproduction | Clean-run record with accessible inputs | Not run |
| Conflicts with evidence | Explanation of any stronger contrary evidence and its resolution | No model choice made |

If the chosen action conflicts with the strongest evidence, do not submit that claim until stronger evidence resolves the conflict. A deadline is a reason to reduce scope, not to omit contradictory results.
