# Project decision

Date: 26 September 2026. Status: **project choice conditional; model performance unmeasured**.

**Execution update, 28 September:** The user requested all experiments with priority work first and independent work in parallel. Use [the complete schedule](10_All_Experiments_Parallel_Schedule.md). Project focus is chosen from evidence; it does not limit exploration to one route at a time. GPU provider, device count, and budget are undecided.

## Recommended first pilot: chip-image quality review

Build a tool that helps a researcher review brightfield organ-on-a-chip images. It would show the image, a predicted sample-quality label, and a queue ordered for human review. Export the prediction, model version, and review status.

The target is agreement with the dataset's expert quality labels. It is not a measurement of cell viability, treatment toxicity, organ function, or clinical safety. The source combines biological appearance and imaging artifacts in the bad class. [Dataset paper, S04](02_Research_Library.md#s04)

**Proposed category:** Tool & Platform. A category declaration is required; this choice is our recommendation. [Official overview, S01](02_Research_Library.md#s01)

**Candidate contribution:** show that a tested review rule catches more bad images at the same review workload, while surviving changes in cell type and acquisition conditions. A classifier, heatmap, or attractive interface alone would not demonstrate that contribution.

## Compare the routes honestly

| Route | Evidence in its favor | Main risk | Present decision |
|---|---|---|---|
| A: Real-chip quality review | Directly relevant public data; metadata and image IDs reconcile; existing papers show the task is studied | Unresolved license discrepancy, uncertain chip grouping, mixed quality labels | First feasibility pilot; moderate confidence in feasibility, no confidence claim about measured gains |
| B: Nucleus counting and review | Small BBBC039 dataset, instance masks, explicit CC0 terms, established comparisons | Crowded field; pretrained overlap; indirect chip relevance | Parallel pilot and independent project alternative; feasibility confidence moderate to high after loading checks |
| C: Cell Painting treatment analysis | Rich public phenotype data and feature tables | Batch effects, large downloads, uncertain endpoint and model rights | Screen immediately; run C01/C02 pilots once a clear biological question and grouped test exist |
| D: Brightfield-to-fluorescence prediction | Established research direction and competition relevance | Requires correctly paired images; visually plausible output can mislead | Screen immediately; C03 runs when suitable pairs and downstream reference measurements are ready |
| E: Digital twin or flow-control simulation | Published control research supports investigating the direction | Same-simulator evaluation can be circular; no real predictive endpoint is ready here | R01 screens prerequisites now; R02 to R04 require a validated environment and separate confirmation before any biological claim |

Sources and the smallest tests for these decisions are in [the research library](02_Research_Library.md) and [playbook](04_Experiment_Playbook.md).

## Decision gates

| Gate | Pass condition | If it fails |
|---|---|---|
| Data | Files open correctly; labels mean what we claim; sources and rights are recorded | Fix loading or select the alternative; do not invent labels |
| Independence | Physical groups are known, or a clearly limited within-dataset claim is chosen with a documented proxy-group sensitivity test | Drop claims about new chips, labs, or donors; evaluate whether the narrower project is still worthwhile |
| Baseline | AI is compared with a simple method and any metadata shortcut on the same held-out groups | Do not claim useful AI contribution; investigate the failure |
| Practical value | A review queue or correction workflow improves a defined task at matched effort | Remove the benefit claim; retain only measured model results |
| Originality | New evaluation, robustness, or workflow benefit is demonstrated beyond the cited work | Narrow the claim; do not call existing models a new algorithm |
| Delivery | Reproducible public code, report, and a working video can be completed | Cut optional models and features first |

Checkpoint: review unresolved Route A prerequisites after the first focused day. Route B and independent source checks proceed alongside that work. A blocked route receives no dependent training until its prerequisites pass; preserve its evidence and exact unblocking requirement. This is a planning checkpoint, not a claim about how long the checks take.

## What could overturn this recommendation?

- A failed grouped evaluation outweighs a strong random-image result.
- If a metadata-only model matches the image model, investigate whether biological information is actually being used. This is a shortcut warning, not automatically proof the image model is useless.
- If a simpler classifier beats the pretrained network reliably, use the simpler classifier where it serves the intended task.
- If the review queue misses a failing cell type, stop promoting general reliability until a separate test validates a guard or the scope is restricted.
- A meaningful, repeated benefit from the nucleus workflow can justify choosing B despite A's closer topic match.
- A clean, accessible external chip dataset could improve A's validation case. A related paper without downloadable data cannot.

No source establishes which route will win. The final decision must be made from actual runs using [the selection rules](05_Validation_and_Selection.md).

## Preserve independent alternatives

Within the chosen task, keep predictions from the simple baseline and the AI method. They may fail differently. A backup is useful only after its performance and any switching rule have been independently checked.

Routes A and B solve different tasks. Their scores cannot be averaged, and B is not a drop-in rescue for a chip-quality classifier. Preserve B as a project alternative, not as an untested ensemble member.
