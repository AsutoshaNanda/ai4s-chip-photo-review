# Experiment and validation playbook

Status: **30 plans; no model runs completed**. G01 contains completed metadata checks, not a completed data/rights gate. Use [the run log](08_Run_Log.md) for measurements.

**High priority does not mean guaranteed positive results.** Confidence below concerns the value of running the test. Every proposed performance gain remains unmeasured. Negative results can save the project from a false claim.

Sources S01 to S31 refer to [the research library](02_Research_Library.md). Metrics, frozen tests, and common promotion rules are defined in [the validation protocol](05_Validation_and_Selection.md).

Cost caps below are proposed limits for initial pilots, not measured runtimes or a project-wide experiment cap. G = shared gate; A = chip quality; B = nucleus analysis; C = conditional extension; F = confirmation and delivery. **All 30 plans are scheduled in [the parallel plan](10_All_Experiments_Parallel_Schedule.md).** Start independent routes and comparisons in parallel after their own prerequisites pass. Choose the final project contribution from the resulting evidence. Additional feature/RL comparisons are defined in that schedule.

## Shared gates

### G01: Verify usable data and rights

- **Priority/confidence:** Required; high decision value. Sources S02 to S04, S08, S15, S17.
- **Question/control:** Do downloaded artifacts match provider records, and can the intended inputs and outputs be used and shared under known terms?
- **Protocol:** Record versions/checksums, reconcile image IDs and labels, open a representative training-only sample, inspect exact model/data terms, and document missing fields. Resolve the OOC license discrepancy. The metadata and archive-directory reconciliation is already saved; pixel integrity and rights are not resolved.
- **Record:** File failures, label definitions, exceptions, intended distribution, and specific unresolved permissions.
- **Decision/cap:** Stop model promotion if the target is unsupported or final distribution cannot be justified. Review unresolved prerequisites after one focused workday; other eligible routes proceed in parallel. Record the exact prerequisite needed to unblock this route.

### G02: Lock groups, splits, and evaluator

- **Priority/confidence:** Required; high decision value. Sources S28, S30 and the direct OOC audit.
- **Question/control:** Are evaluation examples independent of fitting and selection?
- **Protocol:** Verify chip/run groups where possible; keep all related images/crops together. If using filename-prefix groups, call them a proxy. Freeze one primary holdout before training. Check exact-pixel/near duplicates. Verify the evaluator with perfect predictions, all-wrong/all-empty outputs, merged/split objects, and single-class subsets as relevant.
- **Record:** Split IDs, group counts, class counts per fold, duplicate exclusions, and metric edge cases.
- **Decision/cap:** No generalization claim until the stated unit of independence is defensible. Missing chip IDs mean a narrower claim, not invented IDs. Cap initial implementation at half a workday.

### G03: Measure the smallest runnable system

- **Priority/confidence:** Required; high decision value. Sources S01, S17, S27.
- **Question/control:** Can the selected method run and reload within the available resources?
- **Protocol:** Use 16 training examples, one short fitting pass where applicable, then save/reload predictions. Time preprocessing and inference separately on the actual machine.
- **Record:** Package/weight versions, memory, seconds/image, loading failures, output schema, and available compute.
- **Decision/cap:** One hour of setup before choosing a simpler supported option. No full-run cost claim before this measurement.

## Route A: Real-chip quality review

### A01: Establish simple and shortcut baselines

- **Priority/confidence:** First model test; high decision value. Sources S04 to S06, S28.
- **Hypothesis/comparison:** Image information adds value beyond class frequency, cell type, and acquisition metadata.
- **Protocol:** On identical folds compare a training-majority baseline, allowed-metadata logistic regression, and simple image statistics plus logistic regression. Image statistics can include focus, intensity, contrast, and texture. Exclude IDs, paths, and target fields; fit all preprocessing within training folds.
- **Measure:** Balanced accuracy, bad-class average precision, confusion matrices, per-cell-type recall, and runtime.
- **Keep/reject/cap:** Keep all as named comparisons. Strong metadata results trigger shortcut investigation, not automatic image-model rejection. One CPU work session.

### A02: Test one small pretrained image classifier

- **Priority/confidence:** Core; moderate confidence in a gain. Sources S04, S27.
- **Hypothesis/comparison:** A frozen feature encoder plus linear head beats A01; limited fine-tuning may add value.
- **Protocol:** Choose one small architecture, record its weight source/transforms, and compare frozen features against unfreezing only the final block under equal data and bounded tuning. Use loss and label mappings checked in G02. Do not feed label paths.
- **Measure:** A01 metrics, log loss, memory, and latency on the same held-out groups.
- **Keep/reject/cap:** Use the common promotion gate. If it loses, retain the stronger baseline and diagnose one concrete failure. Cap exploratory compute at two accelerator-hours after G03; this is a spending limit, not a speed forecast.

### A03: Test cell-type transfer

- **Priority/confidence:** Core if claiming transfer; high value, uncertain outcome. Sources S05, S21.
- **Hypothesis/comparison:** Performance survives a cell type absent from training.
- **Protocol:** Within development data, leave one cell type out at a time where labels/groups allow it. Never train on the primary final holdout. Compare with group-held-out, seen-cell-type validation. Hold calibrator fitting separate too.
- **Measure:** Each held-out type's class counts, bad recall, false-pass rate, calibration, and worst type.
- **Keep/reject/cap:** A collapsed type invalidates broad transfer claims. Limit scope or validate a detection/review guard. Two representative types first; all eligible types before a claim covering all six.

### A04: Test crop and context dependence

- **Priority/confidence:** Core; high diagnostic value. Sources S04, S06; S25 is supporting analogy.
- **Hypothesis/comparison:** The model uses signal that survives the intended acquisition changes.
- **Protocol:** Compare full field, central crop, and a predeclared context-only view using the same source images/groups and similar training budget. Test small shifts of the crop. Judge whether removed context contains genuine target information.
- **Measure:** Paired metric differences, subgroup errors, and examples whose labels become unsupported by the crop.
- **Keep/reject/cap:** Channel-wall defects and artifacts may legitimately define a bad image. Context dependence alone is not proof of a shortcut. Keep a view only when grouped validation and task meaning support it. One small three-view comparison.

### A05: Test label-preserving augmentation

- **Priority/confidence:** Conditional; moderate decision value, uncertain gain. Sources S04, S21.
- **Hypothesis/comparison:** A small justified transformation set improves transfer without changing quality labels.
- **Protocol:** Compare the fixed A02 setup with and without flips/rotations or small intensity changes after checking their biological and imaging meaning on training samples. Change one augmentation family at a time.
- **Measure:** Grouped validation, worst cell type, and unmodified-image performance.
- **Keep/reject/cap:** Because blur/artifacts can define the bad class, adding blur while retaining a good label may be wrong. Do not use such augmentations without a defensible label rule. At most two variants.

### A06: Test class balancing

- **Priority/confidence:** Conditional on subgroup failure; moderate value. Direct audit plus S28.
- **Hypothesis/comparison:** Training-only class weights or sampling improve the weak class without masking another failure.
- **Protocol:** Compare one weighting policy with the unchanged loss. Do not combine weighting, oversampling, and a new architecture in one test. Use the same group folds and seeds.
- **Measure:** Both class recalls for every type, balanced accuracy, and calibration.
- **Keep/reject/cap:** Reject a gain that sacrifices a required group or creates overconfident errors. HUVEC's small good class requires uncertainty reporting. One variant, then confirmation only if promising.

### A07: Test whether metadata helps honestly

- **Priority/confidence:** Optional; moderate diagnostic value, uncertain gain. Sources S28, S30 and direct audit.
- **Hypothesis/comparison:** Available culture metadata improves image predictions across groups.
- **Protocol:** Compare image-only, metadata-only, and a small fused model. Fit imputers/encoders inside folds. Include missingness indicators; preserve raw flow text and document unit parsing. Also test performance when optional metadata is absent.
- **Measure:** Per-type and per-group results, missing-metadata degradation, and calibration.
- **Keep/reject/cap:** Reject gains that disappear on grouped tests or require metadata unavailable during use. Do not infer flow causality. One fusion variant.

### A08: Calibrate probabilities

- **Priority/confidence:** Core if probabilities are displayed; high test value, moderate expected calibration benefit. Sources S20, S21, S29.
- **Hypothesis/comparison:** A separate calibration fit improves probability accuracy.
- **Protocol:** Compare raw probabilities with temperature scaling or one suitable small calibrator fitted only on disjoint calibration groups. Evaluate on different groups; record cell-type shift separately.
- **Measure:** Brier score, log loss, reliability bins with counts, and results under shift.
- **Keep/reject/cap:** Keep only a supported improvement; remove probability-of-correctness language if unsupported. Binary temperature scaling does not improve ranking at fixed review fractions. One calibrator before considering more complex ones.

### A09: Test the actual review queue

- **Priority/confidence:** Core contribution test; high decision value, uncertain benefit. Sources S06, S19, S21.
- **Hypothesis/comparison:** The proposed queue catches more bad images at the same review effort.
- **Protocol:** Compare random review, focus/brightness rules, descending predicted bad probability, and one proposed uncertainty/disagreement-enhanced score. Freeze the score on development data. Use 10%, 20%, and 30% review fractions, with 20% primary unless a user requirement changes it before testing.
- **Measure:** Fraction of all bad images reviewed, bad images missed, residual bad rate among unreviewed images, and each cell type. Also retain full-set classification results.
- **Keep/reject/cap:** Keep only if it beats the strongest simple queue with supported improvement and no catastrophic subgroup failure. Reviewing everything is not a workload reduction. One matched-queue analysis on saved predictions.

### A10: Test complementary methods and a guard

- **Priority/confidence:** Only after two useful methods exist; moderate value, uncertain gain. Sources S19, S22.
- **Hypothesis/comparison:** Methods fail differently enough for an ensemble or review guard to help.
- **Protocol:** Save a joint error table for both models on the same examples. Compare the best single method, equal-weight average, and one frozen review rule on separate validation groups. Fit any rule without final-test feedback.
- **Measure:** Jointly missed bad cases, cell-type failures, queue utility, calibration, and doubled runtime.
- **Keep/reject/cap:** Reject correlated failures or a rule that merely hides them. Retain an independently confirmed alternative when it catches different failures. One two-model comparison, not an ensemble sweep.

### A11: Test label efficiency

- **Priority/confidence:** Optional; moderate value. Source S13 by analogy, S28 for splitting.
- **Hypothesis/comparison:** A smaller representative labeled set retains useful performance.
- **Protocol:** Use nested 25%, 50%, and 100% training subsets chosen by whole groups; keep validation fixed and repeat the subset selection. If testing active selection, compare with random selection at equal label budget and query training-pool labels only.
- **Measure:** Performance versus actual image/group count, variability, and training time.
- **Keep/reject/cap:** Existing labels simulate annotation availability; they do not measure human annotation time. No annotation-saving claim without a real effort study. Three subset sizes, one architecture.

### A12: Check visual explanations

- **Priority/confidence:** Only if explanations are included; high checking value, uncertain faithfulness. Sources S01, S06.
- **Hypothesis/comparison:** Displayed explanation regions respond meaningfully to the trained prediction.
- **Protocol:** Compare trained versus randomized-model explanations and controlled region occlusion. Use several good, bad, and incorrect predictions. Check whether cropping or masking itself creates a new artifact.
- **Measure:** Prediction changes, explanation changes, and disagreement with visible task-relevant features.
- **Keep/reject/cap:** Treat heatmaps as inspection aids. They do not prove biological causality. Remove misleading explanations. Cap this at one focused review session.

## Route B: Nucleus counting and review

### B01: Establish a correct count baseline

- **Priority/confidence:** Required for B; high decision value. Sources S08, S31.
- **Hypothesis/comparison:** A transparent threshold/watershed pipeline provides a valid reference.
- **Protocol:** Decode instance colors correctly; inspect training overlays; preserve the provider splits and image-level grouping. Tune threshold, marker spacing, and size filters only on validation. Score original-resolution images after restoring crop coordinates.
- **Measure:** Count MAE, object F1 at IoU 0.5, signed bias, dense-image errors, and seconds/image.
- **Keep/reject/cap:** Retain the result even if weak. Fix a broken evaluator before any AI comparison. One CPU work session.

### B02: Compare a small trained model with a modern method

- **Priority/confidence:** Core for B; high comparison value, uncertain winner. Sources S10 to S18.
- **Hypothesis/comparison:** AI adds useful object/count accuracy over B01.
- **Protocol:** Compare a small U-Net trained from scratch and at most one eligible modern alternative, such as StarDist or an audited generalist. Use matched validation and record annotation/training exposure. Unknown pretraining overlap goes in a separate exploratory result row.
- **Measure:** B01 metrics, object merge/split errors, latency, and memory.
- **Keep/reject/cap:** Do not claim novelty from merely using an established model. Select using the common gate. Cap first comparison at two accelerator-hours after timing it.

### B03: Test boundary or distance supervision

- **Priority/confidence:** Only after merged objects are observed; moderate confidence in a useful test. Sources S10, S11.
- **Hypothesis/comparison:** An instance-separation target reduces merges.
- **Protocol:** Keep the small network, split, and training budget fixed; compare foreground-only learning with one boundary or distance target. Tune the separation procedure on validation.
- **Measure:** Object F1, merge/split counts, count bias, and sparse versus dense images.
- **Keep/reject/cap:** Reject reduced merges accompanied by worse fragmentation or count error. One target change.

### B04: Test image robustness

- **Priority/confidence:** Conditional; high diagnostic value, uncertain robustness gain. Sources S14, S21.
- **Hypothesis/comparison:** Useful performance survives plausible acquisition variation.
- **Protocol:** Evaluate fixed, documented brightness/noise/blur levels on validation as synthetic stress tests. Separate this from a training-augmentation comparison. Transform masks consistently for geometric changes and preserve the clean baseline.
- **Measure:** Clean and each stress level separately; worst count error and object F1.
- **Keep/reject/cap:** Synthetic corruption is not a real external dataset. Reject a robustness claim if clean quality collapses. At most three realistic severity levels per chosen family.

### B05: Audit difficult objects and groups

- **Priority/confidence:** Core for B; high decision value. Sources S08, S10, S11.
- **Hypothesis/comparison:** Aggregate improvement survives dense fields and small objects.
- **Protocol:** Define density/size bins from training and development references. Keep them fixed. Review all methods' missed, merged, fragmented, and spurious objects under the same matching rule.
- **Measure:** Per-bin scores, image counts, signed count bias, and a worst-case gallery.
- **Keep/reject/cap:** A near-zero required group reopens selection even if the mean is strong. One analysis of saved predictions.

### B06: Test failure warnings or correction effort

- **Priority/confidence:** Core contribution test for B; high value, uncertain benefit. Sources S13, S18, S19.
- **Hypothesis/comparison:** Method disagreement finds bad counts more effectively than simple quality rules.
- **Protocol:** Compare random review, blur/intensity warnings, count disagreement, and object-mask disagreement at equal image-review fractions. Freeze a large-error definition on development data. If adding interactive correction, measure real corrections and time separately.
- **Measure:** Large errors caught/missed, count error among unreviewed images, whole-set error, and actual correction effort if collected.
- **Keep/reject/cap:** Pixel-level agreement alone may hide missed instances. Retain only the rule that survives separate confirmation. A one-session prediction analysis; human study budget separate.

### B07: Test a clean external distribution

- **Priority/confidence:** Required for cross-dataset claims; high decision value. Sources S08 to S10, S21.
- **Hypothesis/comparison:** The selected method survives a new eligible microscopy distribution.
- **Protocol:** Audit BBBC038 or another compatible dataset for exact/near overlap and model training exposure. Freeze parameters before this evaluation; report external results separately. Known contamination disqualifies the affected row from independent-test claims.
- **Measure:** Every method, distribution, subgroup, and worst case; also warning performance.
- **Keep/reject/cap:** Narrow the use claim if external failure remains. No external validation claim when overlap cannot be resolved. One dataset after the main result is stable.

## Conditional extensions: screen early, run when prerequisites pass

### C01: Batch-held-out phenotype features

- **Priority/confidence:** Scheduled parallel source check and conditional pilot; moderate method evidence, uncertain project value. Source S23.
- **Question/comparison:** Do small precomputed features distinguish perturbations across experimental batches?
- **Protocol:** Verify feature-generation provenance and rights; compare nearest-neighbor retrieval and a simple classifier on held-out experiments. For closed-set classification, test labels need corresponding training classes. Unseen perturbations require a separately defined retrieval or endpoint task.
- **Measure:** Cross-batch accuracy/retrieval, cell-type slices, batch predictability, and runtime.
- **Decision/cap:** Start only if it serves the selected project and passes data gates. A feature-table pilot, no full image download by default.

### C02: JUMP normalization and biological retrieval

- **Priority/confidence:** Scheduled parallel source check and conditional pilot; moderate value. Sources S24, S25, S30.
- **Question/comparison:** Does one normalization reduce technical effects without removing biological signal?
- **Protocol:** Use a small documented subset. Compare raw/eligible minimally processed features with one train-fitted normalization. Distinguish replicate retrieval across batches from unseen-compound endpoint prediction. Separate any transductive use of evaluation inputs.
- **Measure:** Cross-batch replicate retrieval and a separately justified biological endpoint; report both, not one combined score.
- **Decision/cap:** Better batch mixing alone is insufficient. One bounded subset and one normalization method.

### C03: Real paired fluorescence translation

- **Priority/confidence:** Early paired-data check and a scheduled pilot if it passes; low present feasibility. Source S26.
- **Question/comparison:** Does predicted fluorescence preserve a specified downstream measurement?
- **Protocol:** Require real registered input/target pairs and sample-level splits. Compare a simple translator with the unchanged input's best direct downstream method. Check alignment before fitting.
- **Measure:** Structure/count or another justified biological endpoint plus image-similarity metrics; show failures.
- **Decision/cap:** No paired data means do not start. Similar-looking generated images are not evidence of biological correctness. Cap the data search before any training commitment.

### C04: Independent real-chip endpoint

- **Priority/confidence:** Early high-priority source check, followed by independent testing when compatible data is obtained; high validation value, low access certainty. Sources S03, S07.
- **Question/comparison:** Does a compatible quality-review method work on an independent chip source?
- **Protocol:** Verify downloadable images, reference labels, physical groups, rights, and endpoint compatibility. Freeze our model. If the endpoint changes, such as to melanin-region segmentation, report it as a separate task with its own baseline.
- **Measure:** Source-specific errors, queue utility, calibration, and all failed groups.
- **Decision/cap:** A paper reporting data availability is not a completed external test. Do not delay required delivery for inaccessible data.

## Confirmation and delivery

### F01: Independently confirm the candidate

- **Priority/confidence:** Required; high value. Sources S21, S28, S30.
- **Question/comparison:** Is the selected gain repeatable and robust to selection noise?
- **Protocol:** Repeat the candidate and baseline with at least three predeclared seeds when affordable, on the same fixed folds. Seek a separate acquisition group/source where available. Freeze all choices before the final holdout. A rerun on the same images confirms implementation/seed stability, not external validity.
- **Measure:** Paired differences, uncertainty intervals, individual seeds/groups, and worst failures.
- **Decision/cap:** If uncertainty remains wide, report that fact and prefer the simpler supported claim. Reserve compute for this before adding another candidate.

### F02: Measure practical usefulness

- **Priority/confidence:** Required for time/effort claims; high value, benefit uncertain. Sources S01, S06, S13, S18.
- **Question/comparison:** Does the tool reduce actual review or correction effort at acceptable error?
- **Protocol:** If a suitable researcher is available, use predeclared cases and compare ordinary review with tool-assisted review, counterbalancing order or using matched disjoint case sets. Record operator experience and the small-study limits. Do not contact anyone without authorization.
- **Measure:** Time, corrections, missed errors, and usability failures. If no operator participates, report only offline review-budget results.
- **Decision/cap:** Do not convert simulated review coverage into claimed time or cost savings. One small documented study, not an unsupported impact estimate.

### F03: Reproduce from a clean setup

- **Priority/confidence:** Required; high value. Source S01.
- **Question/comparison:** Can the documented entry point recreate saved outputs without hidden state?
- **Protocol:** Run a fresh environment/session from the declared public inputs and exact model version. Regenerate the result tables and example outputs; compare with the saved record using defined tolerances.
- **Measure:** Setup failures, required resources, measured runtime, numerical differences, and missing files.
- **Decision/cap:** Fix failure before submission or remove the unsupported reproduction claim. Reserve one full work session.

### F04: Final claim and submission check

- **Priority/confidence:** Required; high value. Sources S01, S02.
- **Question/comparison:** Does every submitted claim match saved evidence, and is the package accessible?
- **Protocol:** Trace each headline number to a run and prediction artifact. Check contribution statements, failure cases, rights, links in a signed-out session, video length, and the report/code entry point. Write the final selection ledger before submission.
- **Measure:** Missing or inconsistent evidence, inaccessible links, unproven claims, and remaining eligibility actions.
- **Decision/cap:** Correct the package before the final submission action. A draft or a completed experiment is not a submitted Writeup. Reserve the final day as a buffer.
