# Execution schedule and submission

Updated: 28 September 2026, to include all experiments and parallel work.

**Current schedule:** Use [the daily parallel timeline](09_Remaining_Timeline_and_RL_Assessment.md) and [the complete experiment register](10_All_Experiments_Parallel_Schedule.md). Every original plan has a priority, dependency, time window, and output. The earlier one-experiment-at-a-time assumption and global cap of two improvements are replaced.

**Official cutoff:** 10 October 2026, **21:29:59 IST**, confirmed on the live [Kaggle overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview). Internal target: 9 October. Recheck the live deadline before the final action.

## Run independent work in parallel

The user has not chosen a GPU provider, device count, or spending budget and is considering free/low-cost providers and Colab. Keep both single-GPU queue and multi-GPU execution options. Do not assume free quota or paid capacity. Dates are targets until G03 supplies measured run costs.

| Dates | Work running alongside other work | Required decision |
|---|---|---|
| 28 to 29 Sep | G01 to G03 for each route; A01/A02 and B01/B02; source and RL screening | Usable data, protected final tests, measured cost, and explicit blockers |
| 30 Sep to 3 Oct | All eligible A/B comparisons, C01 to C04, X01 and R01 to R05; early F01/F02/F03 work | Results or explicit prerequisite/capacity status for every plan |
| 4 Oct | Candidate selection and development confirmation; demo and reproduction rehearsal | Freeze the supported submission candidates and record why |
| 5 to 7 Oct | F01 locked final tests, F02 usefulness, F03 reproduction, demo and report completion | Confirmed numbers, worst failures, and clean execution |
| 8 to 9 Oct | Report/video/access checks and F04; submit by 9 Oct | Complete, accessible, confirmed submission |
| 10 Oct | Deadline buffer | Verified corrections before the exact cutoff |

The user requested a fuller parallel plan. No training, rental, registration, publication, outreach, or submission was performed by this planning update.

## Budget rules

- Measure a 16-example pilot before predicting the cost of a complete run.
- Keep initial model pilots small per route, with simple controls. The full set of scheduled improvement experiments remains included.
- Run independent changes against the same fixed baseline in parallel; combine supported changes later. There is no project-wide cap of two improvements.
- Reserve at least a third of remaining compute/time for confirmation, failure analysis, and reproduction. This is a planning allocation, not a provider quota.
- Record failed runs and their costs. Stop sessions that are not doing useful computation.
- If capacity becomes tight, prioritize decisive evidence, reuse valid cached work, reduce exploratory scale, and document remaining blockers. Protect confirmation and delivery; stop failed repeated tuning and interface decoration first.

## Match evidence to judging

The weights below are official; the proposed evidence is our response to them. [Official judging](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview#evaluation)

| Judging area | Weight | Concrete evidence to prepare |
|---|---:|---|
| Importance and potential impact | 30% | One research task, intended user, and measured review/correction benefit where available |
| Technical approach and innovation | 30% | Strong baseline, exact reused components, and an ablation showing the new contribution |
| Results and validation | 20% | Valid splits, paired comparisons, groups, worst failures, and confirmation |
| Reproducibility and implementation | 10% | Exact versions, accessible inputs, clean execution, saved results |
| Presentation | 10% | A working input-to-output example and a clear explanation of evidence and limits |

Do not turn these weights into invented project scores or a winning probability. Closer topic relevance helps only when the project also provides valid evidence and a useful contribution.

## Submission package

Verified requirements and recommendations are summarized here; use the full [official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview#submission-requirements) and [rules](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/rules) for the final check.

- Declare one category at the start of the Kaggle Writeup.
- Include a public demonstration video, public code, and a technical report.
- Keep the video within five minutes and accessible without login or payment.
- Show actual inputs, operation, outputs, and representative failure handling.
- Provide the environment, data/model access instructions, evaluation entry point, and exact reproduction steps. Reviewers must have an accessible way to reproduce the work without paid services, proprietary hardware, or non-public data.
- Disclose existing work, data/weight/code sources, rights, and material AI-tool assistance.
- Verify the separate registration form and eligibility requirements. The task's browser showed Kaggle rules had already been accepted, but that does not establish separate registration completion.
- The organizer recommends a 200 to 300 word summary and a self-contained report ideally within 15 to 20 pages excluding references/appendices. Use only as much space as the evidence requires.

## Proposed five-minute video

| Time | Content |
|---|---|
| 0:00 to 0:35 | Researcher's problem and exact input/output |
| 0:35 to 1:45 | Real working example with a saved source image |
| 1:45 to 2:40 | Strongest baseline versus our contribution |
| 2:40 to 3:35 | Difficult case, warning/review behavior, and worst-group result |
| 3:35 to 4:20 | Practical benefit, clearly distinguishing measured from proposed impact |
| 4:20 to 4:55 | Reproduction entry point and key limitations |

Use measured numbers only. Do not use a polished generated animation as evidence of a functioning research tool.

## Open issues before final selection

The OOC license discrepancy, physical group identity, pretrained overlap, compute budget, user benefit, and all model outcomes remain open. Team-formation timing and the overview's bonus wording were already flagged in [the original open questions](../Resources/15_open_questions.md); do not assume those ambiguities have been resolved.
