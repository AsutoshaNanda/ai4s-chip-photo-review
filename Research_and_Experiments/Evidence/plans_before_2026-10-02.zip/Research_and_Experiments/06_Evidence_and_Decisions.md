# Evidence and decisions

Research date: 26 September 2026. No model experiments have been run.

| ID | Observation | Evidence quality | Hypothesis supported or rejected | Changed decision | Smallest next test |
|---|---|---|---|---|---|
| D01 | Existing workspace contains 19 guides and explicitly records no completed experiments. | Direct local inspection | Rejects treating earlier proposed experiments as proven improvements | Keep outcome confidence unmeasured | Build an evidence-ranked research and test plan |
| D02 | A provider lists a real organ-on-a-chip image dataset, expert good/bad labels, six cell types, and an accompanying spreadsheet. | High for provider description; files not yet inspected: [Zenodo](https://zenodo.org/records/10203721) | Supports a directly relevant quality-review route; reopens the earlier nucleus-only plan | Audit real-chip data before choosing the project | Inspect metadata, exact license, and independent sample identifiers |
| D03 | BBBC039 and BBBC038 partly overlap. | High, [dataset provider](https://bbbc.broadinstitute.org/BBBC039) | Rejects treating these as automatically independent tests | Require image-overlap and pretrained-data audits | Identify clean test groups before model selection |
| D04 | Live Kaggle overview confirms judged Writeup, public code, report and video; real chip validation is encouraged. | High, direct browser reading of [official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview) | Rejects a leaderboard-only or generic accuracy-only strategy | Require a measurable research workflow and complete submission package | Map experiments to judging dimensions |
| D05 | The OOC paper states dataset CC-BY-SA, while the downloaded Zenodo API record states cc-by-4.0. | High for conflicting primary-source text: [paper](https://www.mdpi.com/2306-5729/9/2/28), [API](https://zenodo.org/api/records/10203721) | Rejects describing exact reuse terms as fully resolved | Keep distribution/license gate open; do not declare an unrestricted final release | Preserve both records and resolve the discrepancy before redistribution |
| D06 | Downloaded OOC metadata has seven columns and no explicit chip, donor, or experimental-run ID column. | Direct file inspection; MD5 matches provider | Rejects assuming published image splits establish independent-chip validation | Require grouping audit before generalization claims | Reconcile rows with image inventory and inspect identifier prefixes without assuming their meaning |
| D07 | Metadata and complete ZIP64 archive directory reconcile to 3,072 unique PNGs, with 2,130 train, 286 validation and 656 test images; class labels agree. | Direct downloaded metadata and archive-directory audit, [saved JSON](Evidence/ooc_metadata_audit.json); pixels uninspected | Supports practical data availability, not image integrity or model accuracy | Prioritize the real-chip feasibility pilot, pending rights and grouping | Open training images and run duplicate checks on decoded pixels |
| D08 | All 59 filename prefixes occur in multiple published splits, 49 in all three. Prefix meaning is unknown. | High for literal filename overlap; low for inferring shared physical chips | Rejects assuming independent-chip evaluation; does not itself prove leakage | Require a confirmed group split; use prefix grouping only as a labeled sensitivity analysis | Obtain valid group semantics or bound claims to the observed benchmark |
| D09 | Exact hours are missing for 2,244 of 3,072 records; HUVEC has 15 good and 92 bad labels. | Direct spreadsheet counts, [audit](Evidence/ooc_metadata_audit.json) | Rejects a complete time-series assumption and uniform-class assumption | Defer forecasting; require class and cell-type breakdowns | Compare image-only and metadata-only baselines on identical grouped folds |
| D10 | Direct chip-quality classifiers already appear in the dataset paper and later work. | Primary paper/indexed publisher excerpts; [S04 and S05](02_Research_Library.md#s04); no reruns | Rejects a claim that binary chip-quality classification alone is a new contribution | Make review efficiency, robustness, or a demonstrable workflow benefit the candidate contribution | Compare the proposed queue with predicted bad probability and simple quality rules at equal effort |
| D11 | Several contemporary nucleus methods and interactive tools are available. | Maintainer sources and primary abstracts, [S11 to S18](02_Research_Library.md#s11) | Rejects assuming a basic U-Net is sufficient evidence of a competitive technical contribution | Benchmark one eligible modern method before heavy custom-model tuning | Run B02 under audited exposure/rights constraints |
| D12 | General confidence research finds failures under distribution shift. | Primary research, [S21](02_Research_Library.md#s21); indirect to our data | Rejects assuming a confident probability or same-distribution calibration guarantees reliability | Keep shifted groups and worst cases in selection | Test calibration and review performance by held-out cell type/group |
| D13 | The OOC bad label includes some imaging artifacts as well as cell appearance. | Dataset paper text, [S04](02_Research_Library.md#s04) | Rejects equating quality with viability and assuming all blur/crop augmentation preserves labels | Limit the endpoint and audit transformations semantically | Inspect training examples before A04/A05 |
| D14 | A recent Cell Painting preprint reports that encoder rankings change across evaluation protocols. | Provisional primary abstract, [S25](02_Research_Library.md#s25) | Rejects selecting a phenotype model by one unrelated benchmark ranking | Require a task-matched endpoint and separate batch/generalization results | Run C02 only if the phenotype route becomes relevant |
| D15 | Current inspected chip metadata provides no verified paired fluorescence target or causal intervention outcome. | Direct metadata schema plus access limits, [data audit](03_Data_and_Model_Audit.md) | Rejects treating translation, flow control, or toxicity prediction as ready experiments on these inputs | Defer those routes until compatible references exist | For C03, first establish real registered input/target pairs |

## Current decision

**Test Route A's prerequisites first; preserve Route B as the project alternative. Neither route has earned a performance or award claim.**

The strongest new positive evidence is actual access to directly relevant chip-image metadata and a reconciled archive inventory. The strongest unresolved issues are physical sample grouping and the license discrepancy. They change the first work from model tuning to data/validation checks.

The old nucleus-first proposal remains preserved in Resources as historical context. New decisions must use this ledger and actual run evidence.

## Evidence levels

- **Direct local measurement:** file checks, metadata counts, saved predictions, or recorded timings, with artifacts.
- **Primary-source fact:** a rule, provider description, or maintainer statement we read.
- **Published result:** another team's measured finding; not independently reproduced by us.
- **Indirect evidence:** a result from a different task, dataset, modality, or evaluation setting.
- **Assumption/proposal:** a choice such as workload fraction, compute cap, or expected benefit that still needs justification or testing.

Never upgrade one level into another by changing its label. A filename-prefix split remains a proxy until the prefix's meaning is confirmed.

## For every future material result

Record observation, evidence quality, supported/rejected hypothesis, changed action, and the smallest next test. Link the run, split, and saved outputs. If contrary evidence appears, stop promoting the affected strategy and reopen its decision gate.

Final method selection and submission are **pending**. Use [the final selection ledger](05_Validation_and_Selection.md) only after measured results exist.

## 28 September update: remaining time and RL applicability

No model experiment was run for this update. These observations change the planning priorities, not the measured model ranking. See [the daily plan and research references](09_Remaining_Timeline_and_RL_Assessment.md).

| ID | Observation | Evidence quality | Hypothesis supported or rejected | Changed decision | Smallest next test |
|---|---|---|---|---|---|
| D16 | The live overview still gives 10 October 2026 at 21:29:59 IST as the cutoff, expert review on 10 to 20 October, and finals on 20 to 30 October. | High: official page read in the browser on 28 September | Supports a short implementation window and a separate presentation phase | Keep 9 October as the internal submission date; reserve the final week for confirmation and delivery | Close data prerequisites today and time the small pilot |
| D17 | The local run log still has no completed model results; the live account page says no Writeup has been created. Separate registration completion is unverified. | Direct local and browser observations; work outside this workspace was not checked | Rejects assuming the earlier daily plan has already been executed | Shift unfinished prerequisites into 28 September rather than skipping them | Produce the first measured baseline after the data decision |
| D18 | Standard PPO gathers experience through environment interaction; the audited image records do not establish action/outcome trajectories or verified dynamics. | Primary PPO paper plus direct saved metadata audit; applicability is an inference | Rejects assuming PPO can validate fluid control from the present static quality labels | Defer PPO for the present entry unless a working independent control environment becomes available | Check whether such an environment exists before any RL implementation |
| D19 | A 2023 primary study applies PPO to simulated droplet control; a September 2026 preprint reports model-based RL from physical droplet interaction data. | Published research and recent preprint, not local measurements; abstract access limits recorded in the new reference | Supports RL as a real control research direction, but not a proven improvement to this classifier | Preserve the direction as conditional future work; do not dismiss it universally or infer PPO superiority | Require a reference controller and independent dynamics/transfer test |
| D20 | A directly relevant supervised study already uses pretrained image features and simple classifiers for chip quality, with a random image split. | Primary publisher-indexed methods; no local reproduction | Rejects treating ordinary classification or additional feature count as sufficient originality | Prioritize defensible grouping and a matched-workload review contribution | Compare review rules on the same held-out groups |
| D21 | Whole-image information, local regions, and available culture information can be compared without creating a control environment; their benefit is unmeasured. | Experimental proposal, not a result | Supports a cheaper test of the user's multi-feature idea; does not establish a gain | Permit one such addition only when justified by an observed failure | Compare one addition with the image-only baseline, including missing-information and worst-group behavior |

## 28 September update: all experiments and parallel capacity

The following planning decisions supersede the single-track limits in the earlier schedule and the one-addition limit in D21. They do not change the underlying data or validation evidence.

| ID | Observation | Evidence quality | Hypothesis supported or rejected | Changed decision | Smallest next test |
|---|---|---|---|---|---|
| D22 | The user explicitly wants all earlier experiments accommodated and can work on more than one experiment at a time. | Direct user instruction about scope and working style | Rejects the schedule's unsupported assumption of serial work and a project-wide cap of two improvements | Schedule all 30 original plans, map E0 to E6, and include additional feature/RL checks with priority and dependency rules | Verify that every experiment ID has a date window, dependency, and result or blocker field |
| D23 | The user has not selected GPU providers, device count, or budget and is considering free/low-cost options and Colab. | Direct user report; no live quota or rental capacity verified | Rejects promising simultaneous GPU jobs or completion of every full run by a fixed date | Provide both one-GPU-plus-local-work and multi-GPU schedules; measure cost before sizing capacity | Run G03 for each distinct pipeline and calculate the resource queue |
| D24 | Several plans can use shared baselines, cached features, masks, or saved predictions; other plans require new datasets or interaction environments. | Inspection of all 30 protocols; expected cost savings are unmeasured | Supports parallel preparation and analysis; rejects treating every plan as an independent full training run | Reuse only identical-protocol artifacts, separate run outputs, and screen conditional sources immediately | Measure actual reuse and concurrent resource demand in the pilot |

The current complete scope is in [the parallel experiment schedule](10_All_Experiments_Parallel_Schedule.md). No model result, capacity purchase, or actual experiment execution is implied by these changes.
