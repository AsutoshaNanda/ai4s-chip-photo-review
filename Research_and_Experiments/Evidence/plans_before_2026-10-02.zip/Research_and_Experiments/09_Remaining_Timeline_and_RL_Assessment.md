# Remaining timeline and RL assessment

Updated: **28 September 2026, Asia/Kolkata**, to include all experiments and parallel work as requested. This is a planning reference. No training, registration, publication, organizer contact, or submission was performed for this update.

## Recommendation

Give chip-image quality review first priority, while running nucleus counting, independent improvements, and new-data checks in parallel. **All 30 existing plans are scheduled**, with additional global/local feature and RL comparisons. Use [the complete experiment register](10_All_Experiments_Parallel_Schedule.md) for every ID, priority, dependency, date, and decision. Choose the final contribution from measured evidence.

**Confidence:** High in the verified dates, required deliverables, and coverage of the existing plans. Moderate in the priority order. Completion timing is uncertain until data and compute pilots run. No measured evidence yet identifies the best model or supports a predicted ranking.

The current [run log](08_Run_Log.md) contains no model results. The saved [data audit](03_Data_and_Model_Audit.md) establishes metadata availability, but image loading, physical sample grouping, and the recorded license conflict still need decisions. Results produced outside this workspace were not inspected.

## Official dates and scoring

Verified on the live [Kaggle overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview) on 28 September:

- Submission cutoff: **10 October 2026, 21:29:59 IST**, equivalent to 15:59:59 UTC.
- Expert review: **10 to 20 October**; organizers select 20 finalists.
- Final presentations: **20 to 30 October**. Individual presentation appointments were not shown.
- Results: **before November 2026**.
- A separate registration form is mandatory before submission. Its completion has not been verified here.
- The entry is a Kaggle Writeup with a declared category, public code, technical report, and public demonstration video of at most five minutes. A hosted interactive application is optional.

The official scoring weights are impact 30%, technical approach and innovation 30%, results and validation 20%, reproducibility 10%, and presentation 10%. The plan below is our response to those weights, not an organizer-prescribed workflow or a formula for predicting rank. [Official evaluation](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview#evaluation)

## Daily plan

**Capacity update:** The user has not chosen GPU providers or a budget and is considering free/low-cost options and Colab. Do not assume a paid machine, a particular free quota, or multiple available GPUs. The schedule supports both a GPU job queue with parallel local work and multiple independent training slots. Measure G03 first and use the results to size any rental decision. No resource rental or spending is authorized by this plan.

Dates are target windows, not promised runtimes. A listed experiment starts only after its prerequisites pass. All plans remain in the register even if they are blocked by data or capacity.

| Date | First-priority work | Work that can run alongside it | Required output or decision |
|---|---|---|---|
| **28 Sep** | G01/G02 for chip and nucleus data; G03 as soon as each pipeline is ready. Check registration status. | Screen B07 and C01 to C04 sources, R01 control prerequisites, and R05 label-selection feasibility. Start the report outline and F02 task definition. | Source-specific data decisions, protected final-test lists, initial timings, and a visible blocker for each unsupported branch. |
| **29 Sep** | A01 and B01; launch A02/B02 when their baselines and loading checks pass. Finish G03 timing. | Continue source/RL checks; prepare independent A/B comparison configurations, reproduction instructions, and minimal demo input/output. | First measured baselines and a realistic resource queue. GPU training may queue while local work continues. |
| **30 Sep** | Complete A02/B02 pilots; start A03/A04 and B05 failure checks. | Start A05/A06/A07, A11, B03/B04, and eligible C01/C02 pilots. R02 starts only after R01 passes. Finalize C03/C04 source decisions. | Saved predictions, masks, timings, and small independent comparisons against shared baselines. |
| **1 Oct** | Continue A03/A04/B05; start A08/A09/B06 and confirmation of early promising results. | X01 global/local features, A11/A12, remaining A05/A06/A07/B03/B04, and eligible C03/R03/R04/R05. | Each comparison has a result or an explicit dependency/capacity status. No combining untested changes. |
| **2 Oct** | Diagnose weak groups and independently rerun gains. Continue A08/A09/B06. | A10 complementary-method check, B07/C04 external checks when ready, and remaining C/R pilots. Draft demo and report figures from saved outputs. | Evidence about transferable improvements, correlated failures, and practical review benefit. |
| **3 Oct** | Finish eligible A/B comparisons, per-group analysis, and F01 screening confirmations. | Finish C01 to C04/X01/R comparisons that can receive confirmation in time. F02 offline or operator checks and F03 setup rehearsal. | A complete register of results, rejected ideas, and unresolved blockers. Every planned item accounted for. |
| **4 Oct** | Freeze the submission candidates and complete development-side confirmation. | Complete explanation, calibration, and guard checks for retained models; demo and reproduction rehearsal. | A decision ledger based on gains, worst failures, independent alternatives, and delivery feasibility. |
| **5 Oct** | F01 locked final evaluation, including any source reserved as the final external test. | F02 workflow measurement, final demo integration, and report population. | Final numbers for retained claims. Do not tune on the final test afterward. |
| **6 Oct** | Complete the demo and F02 practical-use checks. | F03 clean-run rehearsal, video script, failure examples, and source/rights documentation. | Working workflow and measured effort, or a clearly labeled offline estimate. |
| **7 Oct** | F03 clean reproduction of every retained task/model. | Final report, video rehearsal, and rolling F04 access/claim checks. | Reproduced results, working setup instructions, and fixed delivery failures. |
| **8 Oct** | Complete report and video; F04 checks. | Verify every headline result and public link. | Complete submission package grounded in saved evidence. |
| **9 Oct** | Final evidence/registration/access audit and submission. | Verify the submitted package and retain a local backup. | Confirmed submitted Writeup by the internal target. |
| **10 Oct** | Submission buffer for verified corrections. | Check final status before **21:29:59 IST**. | Complete, accessible package before the cutoff. |
| **11 to 19 Oct** | Preserve the submitted version and prepare the presentation. | Rehearse questions and the offline demo; later research remains separately labeled. | Defensible explanation of the contribution, limitations, and evidence. |
| **20 to 30 Oct** | If selected, follow the assigned presentation slot. | Explain measured value and failure handling. | Final presentation; no assumption that post-deadline work is eligible. |
| **Before November** | Check official results and instructions. | Archive the exact evaluated version. | Use the published outcome rather than guessed rankings. |

The [complete parallel schedule](10_All_Experiments_Parallel_Schedule.md) maps every original experiment, including E0 to E6, and defines X01/R01 to R05. The [playbook](04_Experiment_Playbook.md) retains the detailed controlled comparisons. One changed component per comparison is compatible with several independent comparisons running at once.

## What would most strengthen the entry?

The proposed contribution is a review workflow that finds more poor-quality samples for the same number of images reviewed, with clearly measured limitations across cell types. That could support impact and technical originality together, but it remains a hypothesis.

Ordinary supervised chip-quality classification is established prior work. A directly relevant [primary study](https://pubs.acs.org/doi/abs/10.1021/cbe.5c00087) used pretrained image features and several simple classifiers on A549 and HSAEC images. Its reported evaluation used a random image split. Our decision is to prioritize defensible separation of related samples and useful review behavior. Neither an extra feature branch nor using another model automatically establishes novelty. The study was read through publisher-indexed text and was not reproduced locally.

For each experiment, record the overall score, each supported cell type, the weakest group, and runtime. A strong average cannot excuse a group that fails completely. Repeat promising results and preserve any independently tested method that handles different failures. Use the existing [selection rules](05_Validation_and_Selection.md); its numerical improvement thresholds are proposed planning choices, not competition requirements.

## Does RL or multi-stage PPO fit?

**RL, reinforcement learning, learns which actions to take from their consequences. PPO is one method for training that behavior.** Standard PPO gathers experience by interacting with an environment. [Original PPO paper](https://arxiv.org/abs/1707.06347)

| Idea | Fit for the present project | Smallest useful test or prerequisite |
|---|---|---|
| Whole-image features | Good baseline candidate. These are measurements such as focus, brightness, contrast, and texture. | Compare them with class-frequency and sample-information controls on the same development groups. |
| Whole image plus small regions | Scheduled as X01 after A04; useful to test whether resizing loses local defects. | Compare whole-image-only with combined information. Keep every crop from one source image in the same data partition and score the source image. A bad image does not imply every crop is bad. |
| Images plus culture information | Conditional. Cell type, culture day, density, or flow rate may help, but can also encode acquisition shortcuts. | Compare image-only, information-only, and combined models. Fit missing-value handling on training data only and test absent fields. Never use target labels, label-containing paths, or IDs as model inputs. |
| Staged supervised training | Suitable candidate: reuse existing image features, then fine-tune a small part only if justified, then test the review rule. | Keep each stage only if its benefit survives the same validation protocol. This is not PPO. |
| RL for choosing the next image to label | R05 screens feasibility now and has a conditional pilot window; no demonstrated advantage here. | First run A11 random and simple active-selection controls at equal label count. Existing labels can simulate availability, not actual human annotation time. |
| Multi-stage PPO for pump, pressure, or fluid control | R01 to R04 are included, starting with environment checks. The current image dataset does not support this control task by itself. | Obtain a validated simulator or usable action-and-outcome recordings and independent evaluation before training. Compare ordinary PPO, staged training, and extra global inputs under matched budgets. |

The saved OOC audit reports 3,072 image records, no explicit chip/run identifier, and 2,244 missing exact time values. It does not establish complete trajectories connecting an action to a later outcome. A flow-rate column alone cannot establish what would happen if a controller changed that rate. This makes control-data validation a prerequisite for PPO, not a reason to exclude the RL feasibility check or dismiss RL across life science.

### Research that makes the control direction credible

- **Gyimah et al., 2023:** [Deep reinforcement learning-based digital twin for droplet microfluidics control](https://doi.org/10.1063/5.0159981) uses PPO in a fluid simulator, with pressure and droplet-size observations and inlet-pressure actions. This supports a fluid-control use case, not static image classification. The primary abstract was accessible in indexed text from the [author's university-hosted thesis](https://digikogu.taltech.ee/et/Download/1b5ac438-b9b1-437e-a12c-f54205a6bb9c); the publisher page could not be retrieved and the full thesis exceeded the reader's size limit. No reported result was independently reproduced here.
- **Anand and Kothare, 14 September 2026:** [Autonomous Droplet Navigation via Model-Based Reinforcement Learning](https://arxiv.org/abs/2609.16369) reports learning from physical interaction data to guide droplets through different paths. It is a recent preprint and uses model-based RL, not evidence that PPO is optimal. The primary abstract was inspected; code and experiments were not audited. Its relevance is the need for real action consequences and transfer tests.

If a credible control environment becomes available, a possible research sequence is: compare with a simple feedback controller; train one PPO policy in ordinary conditions; expand training to measured noise and varied dynamics; then test on unseen settings and independent real measurements. Inputs could include current pressure, measured flow, image measurements, target, and recent actions. The reward would measure target tracking and penalties for instability or constraint violations. These are proposed design choices, not a reproduced multi-stage recipe.

Additional inputs are justified only when they improve independent results. A simulation judged solely by the assumptions used to build it cannot establish real biological value. Testing more stages or more features does not repair a missing validation endpoint.

**Before this deadline:** run R01 beside the other data checks. Launch R02 to R04 if a working environment with verified dynamics, a meaningful reference controller, a measurable target, and confirmation capacity is available. Otherwise record the exact blocker. R05 uses a separate label-selection task. New controlled evidence can change priorities immediately.

## Stop rules and fallback

- Start the Route A and Route B prerequisites together on 28 September. A blocked route does not stop an independent eligible route. Nucleus results remain a separate task and must not be presented as chip validation.
- Keep the first model pilots small per route, then run every scheduled independent comparison when eligible. Remove the earlier project-wide limit of two improvements; allocate further work from actual evidence and measured cost.
- Preserve at least a third of remaining effort for confirmation, reproduction, and delivery. This is a planning allocation, not a compute quota.
- If the proposed review order cannot beat predicted bad-image score, use the simpler order and remove the unsupported benefit claim.
- If two controlled attempts fail, stop cosmetic changes and revisit the task or failure explanation. Do not keep searching until one favorable score appears.
- If capacity is insufficient, reduce pilot size, reuse valid shared computations, or add explicitly budgeted capacity. Record any work still blocked. Reduce repeat tuning and visual decoration before sacrificing confirmation or required deliverables.

At the end of each work session, update [the run log](08_Run_Log.md): observation, evidence quality, supported or rejected explanation, changed decision, and smallest next test. Before submission, link the decisive evidence and explicitly resolve any conflict between the selected method and stronger contrary results.
