# Data and model audit

Checked: 26 September 2026. Source descriptions and direct file measurements are separated below.

## Real organ-on-a-chip dataset: directly inspected metadata

Source: [Zenodo record](https://zenodo.org/records/10203721). Local originals: [spreadsheet](Evidence/OOC_datasheet.xlsx) and [record JSON](Evidence/zenodo_10203721_record.json). Analysis: [audit JSON](Evidence/ooc_metadata_audit.json), [archive inventory](Evidence/ooc_archive_inventory.json).

The spreadsheet's MD5 is `a3d4875e3da4da83bac45c0ce727cb40`, matching the provider. Only the last 1,048,576 bytes of the 6,710,767,405-byte archive were fetched. HTTP 206 and the ZIP64 directory confirm that all 3,237 directory entries were read. Images themselves were not decoded.

| Check | Measured finding | Consequence |
|---|---:|---|
| Nonempty image records | 3,072 | Ignore blank formatting rows; the worksheet's 3,119 rows are not the image count |
| Unique IDs | 3,072 | No repeated metadata IDs |
| PNG files in archive directory | 3,072 | All metadata IDs match archive filenames |
| Published train / val / test | 2,130 / 286 / 656 | Save these original assignments before any authorized regrouping |
| Good / bad | 1,727 / 1,345 | Folder labels agree with spreadsheet decisions 1 / 2 |
| Missing exact hours after seeding | 2,244 | Do not assume complete timed sequences |
| Missing seeding density | 344 | Preserve missingness; fit any imputation on training only |
| Missing flow rate | 859 | No full-data flow-response claim |
| Filename prefixes | 59 | Their biological meaning remains unverified |
| Prefixes in multiple published splits | 59 | Investigate related-sample overlap before claiming independence |
| Prefixes in all three splits | 49 | Published stratification is not proof of chip separation |
| Repeated CRC32 plus uncompressed-size pairs | 0 | No candidates under this weak check; exact-pixel and near-duplicate checks remain undone |

These measurements support data availability and expose validation risks. They are not model experiments.

### Cell-type distribution

| Cell type as stored | Good | Bad | Total |
|---|---:|---:|---:|
| A549 | 537 | 238 | 775 |
| CACO | 109 | 237 | 346 |
| HPMEC | 798 | 664 | 1,462 |
| HSAEC | 163 | 81 | 244 |
| HUVEC | 15 | 92 | 107 |
| NHBE | 105 | 33 | 138 |
| Total | 1,727 | 1,345 | 3,072 |

HUVEC's 15 good examples make precise subgroup estimates difficult. Report denominators and intervals. An undefined score in a single-class fold must be shown as unavailable, not zero or silently excluded.

### Label and metadata limits

- Quality labels mix sample appearance with acquisition problems such as blur. Do not translate good/bad into alive/dead or effective/ineffective treatment. [Paper](https://www.mdpi.com/2306-5729/9/2/28)
- Columns are image ID, cell type, seeding density, hours after seeding, day, decision, and flow rate. No explicit chip, donor, or run column exists.
- Date-looking filename prefixes are only candidate grouping keys. Confirm their meaning before treating them as experiments.
- Flow-rate text has several spellings for the same apparent unit. Document parsing and preserve the source value. A missing number is not zero flow.
- Never use the label-containing directory path, filename, or spreadsheet decision as an input feature. Use cell type or culture metadata only in explicitly labeled comparisons.

### License conflict

The [paper](https://www.mdpi.com/2306-5729/9/2/28) states dataset CC-BY-SA. The [downloaded API record](Evidence/zenodo_10203721_record.json) states `cc-by-4.0`. Do not silently choose the more permissive statement. Preserve attribution and resolve the exact terms before selecting a final redistribution plan. This research does not interpret away the conflict.

## Other dataset candidates

| Dataset | Verified source facts | What it can test | Remaining check |
|---|---|---|---|
| [BBBC039](https://bbbc.broadinstitute.org/BBBC039) | 200 DNA-channel images, instance masks, published partitions, CC0 | Nucleus separation and count accuracy | Decode colored masks correctly, open examples, and audit pretrained exposure |
| [BBBC038](https://bbbc.broadinstitute.org/BBBC038) | Diverse nucleus images, published annotations, CC0 | A different imaging distribution | Remove BBBC039 overlap and any known model-training overlap first |
| [RxRx1](https://www.rxrx.ai/rxrx1) | Perturbation images and repeated experimental batches | Cross-batch phenotype analysis | Exact selected asset, license, feature-model provenance, and endpoint |
| [JUMP profiles](https://broadinstitute.github.io/jump_hub/howto/notebooks/11_retrieve_profiles.html) | Downloadable profile tables and processing variants | Replicate matching across batches | Avoid full-dataset preprocessing leakage; use a bounded subset |
| [Skin-on-chip study, 2026](https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2026.1787959/full) | A task-specific brightfield segmentation and quality workflow | A future chip-specific benchmark | Exact usable download and license were not verified |

BBBC masks do not validate brightfield chip quality, whole-cell boundaries, drug toxicity, or organ function. The chip-quality labels do not validate nucleus segmentation. Keep the tasks and result tables separate.

## Model choices and audit gates

| Candidate | Why test it | Important limit |
|---|---|---|
| Small pretrained classifier, for example MobileNetV3 or ResNet18 | Quick Route A transfer-learning comparison using current [Torchvision](https://docs.pytorch.org/vision/stable/models.html) interfaces | Record exact weight enum, transforms, origin, rights, and training exposure; no local timing or performance measured |
| Thresholding plus watershed | Transparent, independent segmentation comparison | Likely to struggle on uneven signal or touching objects; measure it |
| Small U-Net trained from scratch | Clear local-training provenance | Does not establish novelty or beat modern methods by default |
| StarDist | Object-oriented shape prediction for nuclei | Shape assumptions and pretrained DSB exposure must be checked |
| Cellpose 4.2 family | Current maintainer lists Cellpose-SAM updates and DINO-based options | Maintainer flags CC-BY-NC training data; code license alone is not clearance for weights/data; resolve applicability rather than assume prohibited |
| InstanSeg | A separate segmentation method with efficient inference and explicit model indexing | Match modality and pixel scale; inspect each exact checkpoint's model license and training data |
| Segment Anything for Microscopy | Interactive correction could reduce annotation effort | Needs a real correction task and effort measurement; automatic segmentation quality is a separate question |

Sources: [StarDist](https://github.com/stardist/stardist), [Cellpose](https://github.com/MouseLand/cellpose), [InstanSeg](https://github.com/instanseg/instanseg), [microscopy SAM paper](https://www.nature.com/articles/s41592-024-02580-4).

Select at most two AI candidates for the initial pilot. Benchmark paper rankings do not choose the winner for us.

## Before any model is accepted

Record the software version, model identifier, weight checksum, documented training sources, required input scale/channels, data terms, and whether our held-out images could have been seen before. Unknown exposure must be disclosed. Do not describe an unknown-exposure model as a clean external benchmark.

Use the current official API at implementation time. This folder specifies experiments, not a tested software environment. It does not endorse installation commands from old competition repositories.
