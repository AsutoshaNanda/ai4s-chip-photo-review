# Research library

Checked: **26 September 2026**. These are primary papers, author/maintainer pages, data providers, and official rules/docs. Each entry links evidence to an experiment or decision.

**Source confidence** means confidence that the source supports the described finding. It does not mean its method will improve our project. Published results were not reproduced here. Where only abstracts or indexed excerpts were readable, that limit is stated.

## Competition requirements

### S01

**[AI4S official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview)**. Live browser, high confidence.

Expert judging covers importance/impact 30%, technical approach/innovation 30%, results/validation 20%, reproduction/implementation 10%, and presentation 10%. A public video, code, and report accompany the Kaggle Writeup. Real-chip validation is encouraged. **Action:** evaluate a useful workflow and reserve delivery time. **Plans:** G01, F02 to F04. These weights do not give a formula for predicting an award.

### S02

**[AI4S official rules](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/rules)**. Live browser, high confidence in the displayed wording.

The rules permit outside models/data subject to their terms, require attribution and disclosure of prior work, and prohibit fabricated results. Third-party rights remain applicable. **Action:** record licenses separately for code, weights, and data; identify our actual contribution. **Plans:** G01, F04. The collection does not provide a legal interpretation of disputed terms.

## Real-chip quality and practical use

### S03

**[Movčana and collaborators: Organ-on-a-Chip Image Dataset, 2023](https://zenodo.org/records/10203721)**. Provider record plus downloaded metadata; high confidence for access and inventory.

Real brightfield chip images have quality labels and cell-type metadata. The image archive is about 6.7 GB; the spreadsheet is about 120 KB. **Action:** audit the small metadata first. **Plans:** G01, G02, A01 to A12. Our [direct audit](03_Data_and_Model_Audit.md) adds evidence beyond the provider description. Chip/run independence is not established.

### S04

**[Movčana et al., Organ-On-A-Chip Image Dataset for Machine Learning and Tissue Model Evaluation, Data, 2024](https://www.mdpi.com/2306-5729/9/2/28)**. Primary publisher-indexed text reviewed; high confidence for described design, moderate for transfer to our implementation.

The paper describes expert quality judgments, artifact-containing bad images, and a MobileNetV3 transfer-learning example with central crops. It lists the dataset as CC-BY-SA, conflicting with the repository API. **Action:** use a small transfer model as a comparison, test cropping, and resolve rights. **Plans:** G01, A02, A04. Prior classification work limits any claim that binary chip-quality classification is itself new.

### S05

**[Supervised-Learning-Driven Interrogation of Organ-on-a-Chip Quality from Microscopy Images, Chem & Bio Engineering, 2025](https://pubs.acs.org/doi/full/10.1021/cbe.5c00087)**. Publisher-indexed excerpts reviewed; direct full-page retrieval returned 403. Confidence moderate; methods were not fully audited.

The study reports chip-quality classification for A549 and HSAEC, with weaker test results than training results in an expanded task. **Action:** require cell-type results and measure generalization instead of borrowing its score. **Plans:** A01, A03, F01. It is prior art, not independent validation of our proposed model or an assumed independent dataset.

### S06

**[IQT Labs: An AI-based Application Using Organ-on-a-chip Data](https://www.iqt.org/library/an-ai-based-application-using-organ-on-a-chip-data)**. First-party project account; moderate evidence, not a controlled benchmark for our task.

The authors discuss illumination/background differences, uncertain chip identity, and quality triage using confidence. **Action:** test context shortcuts and review efficiency. **Plans:** A04, A09. Their reported success cannot establish that our labels, images, or queue behave similarly.

### S07

**[Yao et al., AI-assisted quantitative analysis for evaluating melanin distribution in 3D pigmented epidermis-on-a-chip models, 7 April 2026](https://www.frontiersin.org/journals/bioengineering-and-biotechnology/articles/10.3389/fbioe.2026.1787959/full)**. Primary paper sections reviewed; moderate evidence for applicability.

The workflow connects brightfield segmentation to interpretable tissue-quality measurements. **Action:** define a task-specific readout, rather than claim biological value from a generic image score. **Plans:** C04, F02. The specific downloadable dataset and its reuse terms were not verified. Do not import its reported agreement rate into our plan as a target or expected result.

## Nucleus segmentation and annotation

### S08

**[BBBC039: Nuclei of U2OS cells in a chemical screen](https://bbbc.broadinstitute.org/BBBC039)**. Provider page read; high confidence.

It provides 200 DNA-channel images, colored instance annotations, published partitions, and CC0 terms. Some images overlap BBBC038. **Action:** use it for a small nucleus test with correct instance decoding and an overlap audit. **Plans:** B01 to B07. It has no chip-quality or toxicity reference endpoint.

### S09

**[BBBC038: Kaggle 2018 Data Science Bowl](https://bbbc.broadinstitute.org/BBBC038)**. Provider page read; high confidence.

Diverse imaging conditions and nucleus annotations make this a candidate second segmentation distribution. **Action:** select an eligible subset only after image and pretrained-training overlap checks. **Plan:** B07. Broad diversity is not proof of independence from BBBC039 or a generalist model's training.

### S10

**[Caicedo et al., Nucleus segmentation across imaging experiments: the 2018 Data Science Bowl, Nature Methods, 2019](https://www.nature.com/articles/s41592-019-0612-7)**. Primary article excerpts reviewed; high confidence in the motivation, indirect evidence for current method choice.

The work studies segmentation across different experiments and explains why generalization matters. **Action:** evaluate objects and unseen conditions rather than only foreground pixels. **Plans:** B02, B05, B07. Historical winning architectures and installation environments are not current recommendations.

### S11

**[Schmidt et al., Cell Detection with Star-convex Polygons, 2018](https://arxiv.org/abs/1806.03535)**. Primary abstract read; high confidence for method description.

Star-shaped object predictions address separating touching nuclei. **Action:** compare an object-oriented model with pixel labeling plus watershed. **Plans:** B02, B03, B05. Shapes outside its representation and different annotation styles may be difficult; improvement here is unmeasured.

### S12

**[StarDist maintainer repository](https://github.com/stardist/stardist)**. Current repository reviewed; high confidence for implementation availability.

Provides maintained code and links to model documentation. **Action:** inspect the chosen pretrained model's training data and rights before use; record its exact release. **Plans:** G01, B02. A code license is not a complete training-overlap audit.

### S13

**[Pachitariu and Stringer, Cellpose 2.0: how to train your own model, Nature Methods, 2022](https://www.nature.com/articles/s41592-022-01663-4)**. Primary method/results excerpts reviewed; moderate confidence in local transfer.

The paper studies iterative correction and fine-tuning with a limited annotation budget. **Action:** compare correction effort with a fixed random-image budget and untouched validation. **Plans:** B06, F02. The small annotation counts that worked in the paper are not a guarantee for our images.

### S14

**[Pachitariu, Rariden and Stringer, Cellpose-SAM: Superhuman generalization for cellular segmentation, 2025](https://www.janelia.org/node/69901)**. Author-institution abstract read; moderate confidence in applicability.

The model adapts SAM within Cellpose and studies robustness to several image changes. **Action:** include a modern generalist as a comparison when rights and training exposure permit. **Plans:** B02, B04. The title and published benchmark claims do not establish superiority on our clean test.

### S15

**[Current Cellpose repository](https://github.com/MouseLand/cellpose)**. Maintainer page read; high confidence for current notices.

The June 2026 update lists new DINO-based models and an updated SAM model. It also flags CC-BY-NC training data. **Action:** use current documentation, record the exact model, and resolve the relevant terms. **Plans:** G01, B02. Do not assume old Cellpose APIs still work or infer automatic legal permission/prohibition from the code license alone.

### S16

**[Goldsborough et al., InstanSeg: an embedding-based instance segmentation algorithm optimized for accurate, efficient and portable cell segmentation, 2024](https://arxiv.org/abs/2408.15954)**. Primary abstract read; moderate confidence in local transfer.

It offers a separate object-segmentation approach and studies speed alongside accuracy. **Action:** measure wall time, memory, and object errors on the same images. **Plans:** B02, G03. Published speedups are hardware- and benchmark-dependent.

### S17

**[InstanSeg maintainer repository](https://github.com/instanseg/instanseg)**. Current repository read; high confidence for documented interfaces.

The repository supports fluorescence and brightfield use and records model versions. Correct pixel size and modality matter. **Action:** inspect the exact model entry and training sources, then run a small image pilot. **Plans:** G01, G03, B02. A model-index example is not proof of a particular weight file's rights.

### S18

**[Segment Anything for Microscopy, Nature Methods, 2025](https://www.nature.com/articles/s41592-024-02580-4)**. Primary abstract and correction notice read; moderate confidence in local transfer.

Microscopy-adapted SAM supports automatic and interactive segmentation through napari. **Action:** evaluate a correction workflow only if annotation effort is the target. **Plans:** B06, F02. Read the updated article and author correction before exact reproduction; the tool is not a verified toxicity model.

## Confidence, failure detection, and independent testing

### S19

**[Zenk et al., Comparative Benchmarking of Failure Detection Methods in Medical Image Segmentation: Unveiling the Role of Confidence Aggregation, 2024](https://arxiv.org/abs/2406.03323)**. Primary abstract read; indirect evidence because its tasks are 3D medical segmentation.

The study favors evaluating error against retained coverage and finds pairwise agreement a useful baseline. **Action:** compare disagreement with blur, random review, and direct error predictors. **Plans:** A09, A10, B06. Whole-image mask agreement can miss count errors; test object/count disagreement separately.

### S20

**[Guo et al., On Calibration of Modern Neural Networks, ICML 2017](https://arxiv.org/abs/1706.04599)**. Primary abstract read; established general method, unmeasured on our data.

Temperature scaling adjusts the meaning of confidence values. **Action:** fit on a separate calibration set and check Brier score and log loss. **Plan:** A08. For binary logits a positive temperature preserves ranking and the 0.5 decision boundary; do not promise an AUC or fixed-queue ranking gain from it.

### S21

**[Ovadia et al., Can You Trust Your Model's Uncertainty? Evaluating Predictive Uncertainty Under Dataset Shift, NeurIPS 2019](https://arxiv.org/abs/1906.02530)**. Primary abstract read; high confidence in the need for shift testing, indirect for this dataset.

Confidence methods can degrade when the evaluation distribution changes. **Action:** retest calibration and review rules by cell type and acquisition group. **Plans:** A03, A08, A09, B07. Familiar-data calibration cannot guarantee unseen-chip reliability.

### S22

**[Lakshminarayanan, Pritzel and Blundell, Simple and Scalable Predictive Uncertainty Estimation using Deep Ensembles, 2017](https://arxiv.org/abs/1612.01474)**. Primary paper landing page and abstract reviewed; moderate transfer confidence.

Separately trained predictors can support uncertainty estimation. **Action:** first test whether two candidate models have complementary errors, then compare an ensemble at equal budget. **Plan:** A10. Two similar networks are not automatically an independent hedge and can agree while both are wrong.

## Phenotyping and alternative endpoints

### S23

**[Recursion: RxRx1](https://www.rxrx.ai/rxrx1)**. Dataset-owner explanation read; high confidence in dataset purpose.

Repeated experimental batches make technical variation a central challenge. **Action:** compare a feature-based classifier or retrieval method across held-out experiments. **Plan:** C01. Genetic perturbation labels are not clinical toxicity labels, and gene-specific effects need care because the provider describes off-target limitations.

### S24

**[JUMP Hub: Retrieve JUMP profiles](https://broadinstitute.github.io/jump_hub/howto/notebooks/11_retrieve_profiles.html)**. Official tutorial read; high confidence for documented access options.

Precomputed profile tables allow small, bounded experiments without downloading the full image collection. Processing variants include batch-corrected outputs. **Action:** record the profile recipe and test whether preprocessing used held-out samples. **Plan:** C02. Do not describe a globally corrected table as a training-only transformation.

### S25

**[Treis et al., Same Encoder, Different Winner: A Paired-View Framework for Cell Painting Encoder Evaluation, 11 September 2026](https://arxiv.org/abs/2609.12761)**. Recent preprint abstract read; provisional evidence.

The authors report that encoder rankings vary by evaluation protocol and image context. **Action:** keep cross-batch biological retrieval and within-study matching separate; use controlled context comparisons. **Plans:** A04 by analogy, C02 directly. The abstract says assets will be released; availability was not verified. Do not make the project depend on those assets.

### S26

**[Christiansen et al., In silico labeling: Predicting fluorescent labels in unlabeled images, Cell, 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6309178/)**. Primary article excerpts reviewed; established direction, conditional feasibility here.

Paired examples can support predicting fluorescent structures from unstained images. **Action:** require real registered pairs and evaluate downstream structures, not just visual similarity. **Plan:** C03. The inspected chip dataset does not establish that paired fluorescence exists.

## Current implementation references

### S27

**[Torchvision: Models and pretrained weights](https://docs.pytorch.org/vision/stable/models.html)**. Current official documentation read; high confidence for API guidance, not tested locally.

Use explicit model weights and their matching preprocessing instead of old examples with ambiguous defaults. **Plans:** A02, G03. Pin the working torch/torchvision combination after the environment smoke test; do not equate a latest documentation page with installed compatibility.

### S28

**[scikit-learn: Cross-validation](https://scikit-learn.org/stable/modules/cross_validation.html)**. Current official documentation read; high confidence.

Group-based splitting is available when samples share a source. **Action:** split physical groups together and fit transformations inside each training fold. **Plans:** G02, A03, C01, C02. A group splitter cannot repair an incorrect or unverified group definition.

### S29

**[scikit-learn: Probability calibration](https://scikit-learn.org/stable/modules/calibration.html)**. Current official documentation read; high confidence.

Calibration requires data separation from the estimator fit and appropriate scoring. **Action:** use a disjoint group calibration set or documented group-aware cross-fitting. **Plan:** A08. With small subgroups, report calibration uncertainty instead of claiming precise reliability.

### S30

**[scikit-learn: Common pitfalls and recommended practices](https://scikit-learn.org/stable/common_pitfalls.html)**. Current official documentation read; high confidence.

Leakage can enter through scaling, imputation, feature selection, or repeated test-driven choices. **Action:** maintain one fixed data contract and transformation pipeline. **Plans:** G02, A07, C02, F01. A high score after leakage is not evidence to retain the method.

### S31

**[scikit-image: Watershed segmentation](https://scikit-image.org/docs/stable/auto_examples/segmentation/plot_watershed.html)**. Current official example read; high confidence for a simple comparison method.

Markers can separate connected foreground objects. **Action:** establish the threshold/watershed baseline and tune only on validation. **Plans:** B01, B03. A toy example is not a measured microscopy result.

## Coverage and remaining limits

This search covered direct chip-quality research, modern nucleus segmentation, human correction, confidence calibration, failure detection, batch effects, phenotype profiles, and fluorescence translation. It prioritized accessible data, controlled tests, current documentation, and delivery within roughly two weeks.

The old [competition notebook review](../Resources/10_current_notebooks.md) remains useful background, but its saved outputs were not rerun and its inventory was not refreshed here. Participant notebooks, votes, paper titles, and public benchmark rankings are not evidence that an approach will win AI4S.

No claim of exhaustive literature coverage or guaranteed experimental success is made. New direct evidence must update [the decision ledger](06_Evidence_and_Decisions.md).
