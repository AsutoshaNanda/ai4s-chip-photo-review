# Experiment run log

**No model experiment has been run.** The completed metadata audit belongs in [the evidence ledger](06_Evidence_and_Decisions.md), not in a model performance table. Blank metrics mean unmeasured.

The [complete parallel schedule](10_All_Experiments_Parallel_Schedule.md) covers all 30 existing plans and six additional feature/RL entries. No jobs were launched by updating that schedule. Record a separate run ID for each actual execution; one experiment plan can produce several runs.

## Parallel queue fields

In addition to the fields below, record priority, status, prerequisite run IDs, owner/operator, device/session, separate output directory, measured pilot cost, projected finish, and any dependency or capacity blocker. Valid statuses are planned, ready, running, measured, confirmed, rejected, blocked by prerequisite, blocked by capacity, and not applicable with evidence.

GPU provider, device count, quota, and spending budget are undecided. Do not record available paid capacity or guaranteed free capacity until verified. A run that has not executed has no measured score.

## Register a run before executing it

| Field | Required entry |
|---|---|
| Run ID and plan ID | Unique run ID; G/A/B/C/F plan from the playbook |
| Date and operator | Actual execution date and responsible person/agent |
| Hypothesis | What the comparison can support or reject |
| Primary outcome and margin | One primary metric, direction, and practical threshold |
| Data | Source, version, hashes, target label meaning, rights status |
| Independence unit | Confirmed group definition, or explicitly labeled proxy |
| Split manifest | Exact train/development/calibration/test IDs and manifest hash |
| Method/control | Baseline and candidate; one changed component |
| Model provenance | Exact weight ID/hash, training sources, and overlap status |
| Configuration | Versions, seed, hyperparameters, transforms, and stopping rule |
| Budget | Machine, measured pilot speed, runtime/memory cap |
| Saved outputs | Planned prediction, metric, figure, and log locations |

## Complete immediately after execution

| Field | Required entry |
|---|---|
| Observation | Actual numbers, failures, and missing outputs |
| Evidence quality | Direct measurement, reproduction, independent test, or proxy |
| Overall outcome | Baseline and candidate under identical metrics |
| Per-group outcome | Cell type, physical group, distribution, and guard state as applicable |
| Worst failures | Sample IDs, images/overlays, and observed consequences |
| Uncertainty | Paired interval, seed variation, sample/group counts, limitations |
| Runtime/cost | Measured, not predicted |
| Hypothesis decision | Supported, rejected, or inconclusive |
| Changed action | Keep, reject, narrow scope, or investigate |
| Smallest next test | One concrete follow-up, with a reason |
| Record links | Code/config version and saved predictions/results |

Do not finish a material-result entry without its changed decision and next action. Add failures and contradictions to the main evidence ledger immediately.

## Comparison register

| Run | Plan | Split | Method | Primary result | Worst group | Runtime | Evidence quality | Decision |
|---|---|---|---|---|---|---|---|---|
| Not run | | | | | | | | |

## Suggested prediction records

For classification, save image ID, group ID/type, cell type, original split, evaluation split, true label, predicted bad probability, predicted label, review score, review status, model ID, and latency.

For nuclei, save image ID/group, reference and predicted counts, TP/FP/FN under the fixed matching rule, count error, warning score, predicted-mask location, model ID, and latency.

Do not save only a mean score. Per-sample predictions are needed to compare errors, detect complementary methods, and audit the final table.

## Final selection record

Chosen task/category: **pending**.

Chosen method: **pending**.

Decisive runs and independently confirmed benefit: **pending**.

Worst-case failures, tested fallback, and excluded claims: **pending**.

Rights/overlap resolution and clean reproduction: **pending**.

Reason the choice follows the strongest evidence: **pending**.

No submission is justified by the existence of this blank template.
