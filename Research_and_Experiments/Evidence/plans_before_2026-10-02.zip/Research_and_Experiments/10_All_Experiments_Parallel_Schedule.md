# All experiments: priority and parallel schedule

Updated: **28 September 2026, Asia/Kolkata**, following the user's request to accommodate every experiment and run independent work in parallel.

**All 30 existing experiment and validation plans are included below.** The earlier E0 to E6 list is mapped to those plans. Additional whole-image/local-feature and RL ideas are also scheduled separately. This file replaces the earlier assumption of one experiment at a time and the project-wide limit of two improvements.

This is a schedule, not an execution report. No new model results exist. The user has not chosen providers, GPU count, or spending budget and is considering free/low-cost options and Colab. Operator availability is also unconfirmed. No rental or spending is authorized by this plan. Parallelism can increase coverage, but it does not establish an optimal model or a likely ranking.

## How to use the priorities

- **P0:** First claim on available resources: trustworthy data, core comparisons, major failure checks, confirmation, and delivery.
- **P1:** Run beside P0 when dependencies and resources allow. These are scheduled experiments, not a discarded backlog.
- **P2:** Begin the prerequisite check immediately. Run the method when suitable data, a meaningful task, and capacity are established.

Priority controls resource contention. Independent work does not have to wait for every higher-priority experiment to finish. A failed prerequisite must be recorded as blocked or not applicable, not as a completed experiment. A promising result can raise any experiment's priority; contradictory evidence reopens its affected decision immediately.

## Parallel work tracks

| Track | Work | Resource use and sharing |
|---|---|---|
| Shared checks | G01 to G03, file loading, split definitions, source/rights checks, duplicate checks | Mostly local CPU and inspection. Reuse tooling, but define a separate valid data contract for each task. |
| Chip quality | A01 to A12 and X01 | One training slot when available. Image statistics, cached-feature fitting, scoring, and review analysis can overlap training. |
| Nucleus counting | B01 to B07 | Start B01 without waiting for the chip route to fail. B02 uses a separate training slot or the priority queue. Later analyses reuse masks and predictions. |
| Additional datasets and RL | C01 to C04 and R01 to R05 | Research, small downloads, rights checks, and metadata work can overlap both main tracks. Training requires its own passed checks and allocated capacity. |
| Validation and delivery | F01 to F04, demo, report, video | Start setup and drafting early. Protect final confirmation and reproduction capacity for every model or task retained in the submission. |

## Complete coverage: the original 30 plans

The dates are target windows. Prerequisites must pass before a dependent run starts, even when both appear on the same date. Read the full protocol and keep/reject rules in [the experiment playbook](04_Experiment_Playbook.md).

| ID | Priority | Experiment or check | Target window | Must be ready first | Output or decision |
|---|---|---|---|---|---|
| G01 | P0 | Usable data, labels, and rights | 28 Sep; each new source before use | Source files and proposed use | Verified input contract or an explicit blocker for each route. |
| G02 | P0 | Separate related samples and check scoring | 28 to 29 Sep; each new source before fitting | G01 for the source | Fixed train/development/calibration/final-test lists and checked scoring code. |
| G03 | P0 | Small runnable pilot and timing | 28 to 29 Sep; each distinct pipeline | G01/G02 for the pipeline | Save/reload proof, memory, speed, and a measured run-budget estimate. |
| A01 | P0 | Simple image and metadata comparisons | 29 Sep | Chip G01/G02/G03 | Majority, image-statistics, and metadata-only results on identical splits. |
| A02 | P0 | Pretrained features and staged fine-tuning | 29 to 30 Sep | A01 reference and valid chip pipeline | Frozen-feature and limited-fine-tuning comparison, with saved predictions. |
| A03 | P0 | Transfer to unseen cell types | 30 Sep to 3 Oct | A02 configuration and valid development groups | Each eligible type, class counts, worst type, and the resulting scope limits. |
| A04 | P0 | Full-image, crop, and context dependence | 30 Sep to 1 Oct | A01/A02 and label-preserving view definitions | Matched view comparisons; evidence about useful signal or shortcuts. |
| A05 | P1 | Label-preserving image changes during training | 30 Sep to 2 Oct | A02 and inspected training examples | A controlled transformation comparison; no blur added with an invalid unchanged label. |
| A06 | P1 | Class weighting or sampling | 30 Sep to 2 Oct | A01/A02 class and subgroup errors | One balancing-policy comparison with both classes and worst types reported. |
| A07 | P1 | Images plus culture information | 30 Sep to 2 Oct | A01/A02 and verified available fields | Image-only, metadata-only, combined, and missing-field results. |
| A08 | P0 | Check and correct probability confidence | 1 to 3 Oct; refresh for final candidate | Candidate predictions and disjoint calibration groups | Probability-error scores and reliability by group. Remove unsupported confidence claims. |
| A09 | P0 | Review order at equal workload | 1 to 3 Oct; freeze 4 Oct | A01/A02 predictions and separate rule-selection/evaluation data | Bad samples caught at 10%, 20%, and 30% review, including each supported type. |
| A10 | P1 | Complementary models and failure guard | 2 to 3 Oct | Two eligible methods with saved predictions | Joint failures, simple combination, guard behavior, and runtime. No gain assumed from model count. |
| A11 | P1 | Label efficiency and active selection | 30 Sep to 3 Oct | Fixed A02 setup and a training-only label pool | Nested 25%/50%/100% group subsets, repeated selections, and random versus active selection at equal budget. |
| A12 | P1 | Check visual explanations | 1 to 3 Oct | A02 and a proposed explanation method | Randomized-model and region-removal checks. Remove explanations that mislead. |
| B01 | P0 | Simple nucleus-counting comparison | 29 Sep | Nucleus G01/G02/G03 | Correct decoded masks, threshold/watershed counts, errors, and runtime. |
| B02 | P0 | Small trained model versus modern method | 29 to 30 Sep | B01 and model-rights/exposure audit | Same-image comparison, saved masks, counts, and timing. |
| B03 | P1 | Boundary or distance training targets | 30 Sep to 2 Oct | B02, with evidence of merged-object errors | One changed target; merged, fragmented, missed, and count errors. |
| B04 | P1 | Image robustness | 30 Sep to 2 Oct | B02 and documented plausible changes | Clean and each synthetic stress condition separately; one justified training change if needed. |
| B05 | P0 | Difficult objects and groups | 30 Sep to 3 Oct | B01/B02 saved predictions | Dense/sparse and small/large-object results, with a worst-case gallery. |
| B06 | P0 | Error warnings and correction workflow | 1 to 3 Oct; operator test in F02 | B01/B02 predictions and fixed large-error definition | Equal-workload comparison against random and simple warnings; real correction time separately. |
| B07 | P1 | Independent microscopy dataset | Screen 28 to 30 Sep; test 2 to 3 Oct if ready | B02 plus G01/G02 for a compatible source with overlap audit | Per-source errors and warning behavior. If data are not independent, record the limitation. |
| C01 | P1 | Cell features across experimental batches | Screen 28 to 29 Sep; pilot 30 Sep to 2 Oct | Source-specific G01/G02/G03 and a defined biological task | Small feature-table comparison, held-out-batch results, and runtime. |
| C02 | P1 | JUMP normalization and biological retrieval | Screen 28 to 29 Sep; pilot 30 Sep to 2 Oct | Eligible profiles and their processing history; independent of C01 | Raw versus one training-fitted adjustment, with biological signal and technical effects measured separately. |
| C03 | P2 | Brightfield-to-fluorescence prediction | Screen 28 to 30 Sep; pilot 1 to 3 Oct if ready | Real aligned pairs, rights, separate sample groups, and a downstream reference | Simple prediction model versus direct analysis of the original image; meaningful measurement plus visual errors. |
| C04 | P0 | Independent real-chip validation | Screen 28 to 30 Sep; development check 2 to 3 Oct or reserved final check 5 Oct | Compatible source, labels, rights, and groups; trained A model | External performance and review utility. Choose development or final-test role before use. |
| F01 | P0 | Confirm selected improvements independently | Start promising reruns 1 to 3 Oct; confirm 4 Oct; locked final test 5 Oct | Baseline/candidate artifacts and protected final data | Individual runs, paired differences, worst groups, and uncertainty for every retained claim. |
| F02 | P0 | Practical usefulness | Define task 28 to 30 Sep; offline checks 1 to 3 Oct; timed use 3 to 6 Oct if available | Working review/correction flow and appropriate operator for time claims | Measured effort and errors, or an explicitly labeled offline estimate. No outreach is authorized by this plan. |
| F03 | P0 | Clean reproduction | Build instructions from 29 Sep; rehearsal 4 to 6 Oct; final check 7 Oct | Versioned inputs, environment, models, and evaluation entry point | Reproduced results and a record of setup failures and fixes. |
| F04 | P0 | Claims, access, and submission | Rolling from 28 Sep; final audit 8 to 9 Oct | Evidence ledger, report, code, video, eligibility check | Traceable claims and confirmed submission by the internal 9 October target. |

G01 to G03 are repeated per independent task/source as needed. F01 to F04 cover every method or task included in the final entry. The 30 IDs describe plans, not a promise that exactly 30 training jobs will suffice.

## Original E0 to E6: no work lost

| Earlier experiment | Covered by |
|---|---|
| E0: image/mask loading | G01, G02, B01 |
| E1: simple nucleus count | B01 |
| E2: small U-Net | B02 |
| E3: separate touching nuclei | B03 |
| E4: training flips/rotations | B04, with clean-image validation |
| E5: warnings for bad counts | B05, B06 |
| E6: fresh run and final test | F01, F03 |
| Earlier extra external-data test | B07 |

These are the [original plans](../Resources/06_experiments.md), mapped rather than duplicated as unnecessary extra runs.

## Additional feature and RL experiments

These six entries supplement the original 30. Their results are unmeasured. Research supporting the control direction and its current data limits is in [the RL reference](09_Remaining_Timeline_and_RL_Assessment.md#does-rl-or-multi-stage-ppo-fit).

| ID | Priority | Comparison | Target window and dependency | Keep/reject decision |
|---|---|---|---|---|
| X01 | P1 | Whole-image features versus whole image plus local regions | 1 to 3 Oct after A04 and a stable A02; metadata combination only after A07 shows value | Use matched source-image splits and comparable training budgets. Do not assign the image's label blindly to every crop. Add combined features only after their individual value is understood. |
| R01 | P2 | RL feasibility: controllable actions, outcomes, and reliable environment | 28 to 30 Sep, alongside C-source checks | Require an observable objective, meaningful actions, validated dynamics or usable interaction data, and independent evaluation. Static quality labels alone do not pass. |
| R02 | P2 | Simple feedback controller versus ordinary PPO | 30 Sep to 1 Oct if R01 passes, with source-specific G01/G02/G03 | Compare tracking error, constraint failures, worst conditions, training interactions, and runtime. Keep a fair reference controller and record all failed runs. |
| R03 | P2 | Ordinary PPO versus multi-stage training | 1 to 3 Oct after R02 | Compare the same total interaction budget: ordinary conditions, then justified noise/dynamics variation. Test untouched conditions. Record each stage; do not credit extra training budget to the staging method. |
| R04 | P2 | Minimal control inputs versus multiple global features | 1 to 3 Oct after R02; independent of R03 | Compare available pressure/flow/image/history inputs under matched budgets. Fit scaling on training only, exclude future information, and test missing/noisy inputs. Combine with R03 only after isolated effects are known. |
| R05 | P2 | RL-based label selection versus random and simple active selection | Screen 28 to 30 Sep; pilot 1 to 3 Oct after A11 controls and a valid repeated-selection task | Reveal labels only from the training pool. Match annotation and compute budgets, report selection-run variability, and keep final-test labels hidden. Existing labels do not measure human labeling time. |

R05 is a different task from fluid control and does not depend on R02. A positive result on either task must receive F01 confirmation before becoming a headline claim. If R01 fails, R02 to R04 remain blocked with the exact missing prerequisite; they are not silently removed or called tested.

## Resource-aware execution

Do not assume that two jobs running on one GPU will finish faster. G03 measures whether concurrency fits memory and improves throughput. Start all independent low-cost work that fits available CPU, memory, storage, and network limits.

| Available capacity | Execution policy |
|---|---|
| One GPU plus a local computer | Queue accelerator jobs by priority, while local data checks, small CPU models, saved-prediction analyses, and report work continue. Start A02 and B02 in the same early window, using sequential GPU slots if needed. |
| Two GPUs or independent training sessions | Give A and B one slot each initially. Keep source checks and scoring outside those slots where possible. Reassign freed capacity using actual results. |
| More independent capacity | Start eligible C/R pilots and split A/B comparisons across slots. Preserve confirmation capacity and a shared fixed protocol. |

After the first pilot, write available device-hours, measured run durations, memory limits, and operator review time into the run log. For each job, compare its projected finish with the 4 October selection target and reserved confirmation/reproduction windows. An infeasible job stays explicitly queued or blocked by capacity; add actual capacity or reduce its exploratory size. Never quietly turn a partial comparison into a completed result.

The initial A02 and B02 model limits remain small pilot comparisons per route. There is **no project-wide limit of two improvement experiments**. Run A05, A06, A07, B03, B04, and other independent changes against their shared route baseline. Only combine supported changes afterward.

A single-factor comparison changes one component at a time; it does not require running only one experiment at a time. Shared baseline predictions can be reused only when data splits, seed, preprocessing, model version, and evaluation protocol match. Keep immutable configurations and separate output folders so parallel runs cannot overwrite each other.

## Daily decisions and finish conditions

1. **28 to 29 September:** Set up all tracks. Complete core prerequisites, start both main baselines, and screen every conditional dataset/RL requirement. Build the measured resource queue.
2. **30 September to 3 October:** Run all eligible comparisons in parallel, with P0 first. Repeat promising signals as they arrive. Every registered experiment receives a real result or an explicit prerequisite/capacity status.
3. **4 October:** Select the strongest supported contribution and freeze the submission candidates. Broad research coverage does not require presenting unrelated tasks as one scientific result. Keep separately validated alternatives and supplementary results.
4. **5 to 7 October:** Run locked final evaluation, complete the demo and practical-use checks, and reproduce the selected work. Extra exploration may use spare capacity only if it cannot contaminate final testing or delay delivery.
5. **8 to 10 October:** Complete and submit the package by 9 October; keep 10 October as the deadline buffer. A late improvement can enter only if it receives genuinely unused confirmation data, a complete reproduction check, and an updated decision ledger before submission.

Do not compare chip-classification, nucleus-counting, phenotype, and control metrics as though they measure the same task. Select the final story from measured usefulness, technical contribution, reliability, and deliverability. A route with severe unexplained group failure cannot be rescued by averaging its score with another task.

## Status and evidence rules

Use these statuses: **planned, ready, running, measured, confirmed, rejected, blocked by prerequisite, blocked by capacity, or not applicable with evidence**. No new experiment is currently running under this plan. None is measured or confirmed.

At registration, record plan ID, owner/operator, input/model version, split, metric, comparison, machine, estimated cost from G03, and output path. At completion, record the observation, evidence quality, supported/rejected explanation, changed action, and smallest next test. Keep failure outcomes and incomplete jobs visible.

More comparisons increase the chance of an accidental good score. Use development data for exploration, reserve final data from the start, confirm the selected improvements, and report the number of comparisons tried. Repeated seeds test training stability, not biological independence.

Protect at least a third of total remaining effort for confirmation, error diagnosis, reproduction, and delivery as an initial planning allocation. Rebalance using measured run cost. Stop repeating a failed approach after two controlled unsuccessful repairs; reopen its explanation or try a structurally different method. Evidence, not the planned priority label, decides promotion.
