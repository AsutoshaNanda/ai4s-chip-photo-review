# AI4S research and experiment collection

Checked: **26 September 2026, Asia/Kolkata**.

**28 September update:** All 30 existing plans are now included in [the full parallel experiment schedule](10_All_Experiments_Parallel_Schedule.md), alongside the additional feature and RL ideas. Use [the daily timeline](09_Remaining_Timeline_and_RL_Assessment.md) for the calendar. The deadline was checked earlier today; no model results have been added.

**Give real organ-on-a-chip quality review first priority, while starting nucleus counting and independent prerequisite checks in parallel.** Use measured results to choose the final contribution. Additional routes can start their own pilots once data, rights, validation, and compute requirements pass.

This folder collects 31 research, data, rules, and implementation references, plus 30 experiment and validation plans. It covers the main practical routes found in this research, not every paper or every possible experiment.

**Confidence:** High that the priority checks will make project selection and evidence stronger. Moderate that either proposed project is feasible within the remaining time. Whether a method improves performance is unmeasured. A win cannot be guaranteed.

## Read in this order

| File | Purpose |
|---|---|
| [01 Project decision](01_Project_Decision.md) | Which project to test first, why, and when to switch |
| [02 Research library](02_Research_Library.md) | Primary sources, useful findings, limits, and linked experiments |
| [03 Data and model audit](03_Data_and_Model_Audit.md) | Verified data facts, actual metadata counts, and unresolved issues |
| [04 Experiment playbook](04_Experiment_Playbook.md) | Controlled comparisons, confidence, cost caps, and keep/reject rules |
| [05 Validation and selection](05_Validation_and_Selection.md) | Splits, metrics, uncertainty, worst cases, and final choice rules |
| [06 Evidence and decisions](06_Evidence_and_Decisions.md) | What the evidence changed and the next required action |
| [07 Schedule and submission](07_Schedule_and_Submission.md) | Priority rules and the judged submission package |
| [08 Run log](08_Run_Log.md) | Where actual measurements must be recorded |
| [09 Daily timeline and RL](09_Remaining_Timeline_and_RL_Assessment.md) | Daily parallel work and applicability of feature/RL ideas |
| [10 All experiments](10_All_Experiments_Parallel_Schedule.md) | All 30 plans, original E0 to E6 mapping, six additional feature/RL checks, and resource allocation |

## Most valuable findings

1. A public real-chip dataset has **3,072 image records**. Its spreadsheet and archive filenames were independently reconciled here. [Audit](03_Data_and_Model_Audit.md)
2. Physical chip/run identifiers are not explicit. All 59 filename prefixes cross published splits. This is a reason to investigate related samples, **not proof of leakage**. [Saved measurements](Evidence/ooc_metadata_audit.json)
3. The dataset paper lists CC-BY-SA, but its repository API lists CC BY 4.0. Exact distribution terms remain unresolved. [Sources and decision](06_Evidence_and_Decisions.md)
4. Modern segmentation methods make a basic U-Net alone a weak originality claim. A useful contribution could be a measured reduction in review effort or missed failures. That benefit must be tested. [Research](02_Research_Library.md)

## First actions

- Complete **G01 and G02**: settle the data contract and define a valid split before training.
- Run **A01 and A02** if the real-chip route passes. Compare simple image features, metadata shortcuts, and one small pretrained classifier.
- Run **A04 and A09**: check what the classifier uses and whether a review queue catches bad samples better than simple alternatives.
- Start **B01 and B02** on BBBC039 in parallel after their own prerequisites pass. Do not call fluorescence nucleus results chip validation.
- Start **C01 to C04 and R01/R05 prerequisite checks** immediately; launch eligible method comparisons in their assigned windows.
- Preserve time for **F01 to F04**: repeatability, practical benefit, clean reproduction, and final submission checks.

The [full experiment schedule](10_All_Experiments_Parallel_Schedule.md) assigns every plan a priority, date, dependency, and output. Run independent work in parallel; keep unresolved prerequisites and capacity limits visible. The [submission guide](07_Schedule_and_Submission.md) protects final confirmation and delivery.

## What was actually done

- Read all 19 original guides and moved them unchanged into [Resources](../Resources/00_READ_FIRST.md).
- Read the live competition overview and rules in the browser.
- Reviewed the linked papers, provider pages, and current maintainer documentation, with access limits stated in the library.
- Downloaded the small public OOC spreadsheet and record metadata, and read the archive directory using a 1 MiB range request.
- Checked IDs, counts, labels, missing fields, and filename-prefix overlap.

**No image pixels were inspected, no model was trained or scored, and no competition entry was submitted.** The large image archive and model weights were not downloaded. No paper's reported score is presented as our result.

The original-file checksums are in [the organization manifest](organization_manifest.json). The [evidence folder](Evidence/ooc_metadata_audit.json) holds the small downloaded sources and measured audit results.
