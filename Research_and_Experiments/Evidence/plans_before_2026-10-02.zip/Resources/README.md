# AI4S beginner guide

Checked: **26 September 2026, IST**.

**Start here:** This is a judged project hackathon. Build something useful, test it honestly, and submit a Kaggle Writeup with a video, public code, and report.

**Deadline:** 10 October 2026, **9:29 PM IST**. Aim to submit on 9 October. [Official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview)

## Read in this order

| File | What it answers |
|---|---|
| [01 Overview](01_overview.md) | What is the competition? How is it judged? |
| [02 Rules](02_rules_and_dates.md) | What must we follow? |
| [03 Data](03_data.md) | Which data exists, and which should we inspect first? |
| [04 Reading](04_what_to_read.md) | What should a beginner learn? |
| [05 Work](05_what_to_build.md) | What small project could we finish? |
| [06 Experiments](06_experiments.md) | What should we test, and when should we stop? |
| [07 Similar competitions](07_similar_competitions.md) | Which past ideas might help? |
| [08 Resources](08_tools_and_free_compute.md) | Which tools and free training services can we use? |
| [09 Discussions](09_current_discussions.md) | What have the host and participants said? |
| [10 Notebooks](10_current_notebooks.md) | What does current code show, and what can we reuse? |
| [11 Schedule](11_work_schedule.md) | What should be finished each day? |
| [12 Submission](12_submission_checklist.md) | What must be ready before submitting? |
| [13 Decisions](13_evidence_and_decisions.md) | Which evidence changes the plan? |
| [14 Experiment log](14_experiment_log.md) | Where do we record real results? |
| [15 Open questions](15_open_questions.md) | What is still unverified? |
| [16 Writeup template](16_writeup_template.md) | How do we explain the finished project? |
| [17 Glossary](17_glossary.md) | What do unfamiliar words mean? |
| [18 Sources](18_sources.md) | What was checked, and how? |

**Evidence labels:** “Verified” means the cited source says it. “Reported” means someone else claims it. “Proposed” means a plan to test, not a result.

No models were trained or independently rerun for these guides. No performance or winning chance is claimed.

