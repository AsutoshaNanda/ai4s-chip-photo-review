# What to work on

**Proposed project:** A nucleus-counting and review tool for research images.

**Confidence:** Moderate that this is a manageable starting scope. Performance, originality, user benefit, and suitability for an award remain untested.

## Smallest useful version

Input: a microscope image.

Output:

1. Colored outlines around each detected nucleus.
2. A count and a table of nucleus sizes in pixels.
3. Warnings for questionable images or disagreeing methods.
4. A downloadable results table with the method and settings.

Proposed category: **Tool & Platform**.

Use a simple brightness-based method as the comparison. Add a small U-Net, an AI model that labels image pixels, then separate touching nuclei. Train only on the permitted training images.

## Our possible contribution

Test whether a review warning helps users identify unreliable counts. Compare its error detection against a simple brightness/blur warning. A warning is only useful if measured errors support it.

Do not call an existing model our invention. Clearly credit the model and explain the added evaluation or workflow.

## Why this direction is proposed

- The [host accepts public cell-imaging data](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/737840).
- [BBBC039](https://bbbc.broadinstitute.org/BBBC039) supplies reference outlines.
- A count-and-outline demo is easy to inspect.
- The remaining time favors one complete workflow.

**Limit:** A useful microscopy component could later support chip research. Success on these images would not prove it already works on chips.

## Alternatives and stop rules

| Route | Start only when |
|---|---|
| Treatment-response image analysis | Labels, rights, and a test excluding training compounds are ready |
| Bright-field to fluorescence prediction | Real matched image pairs and a trustworthy test are available |
| Simulated chip model | Simulation itself is the stated contribution, with assumptions and limits disclosed |

By 28 September, if reference masks cannot be read correctly, fix data loading before modeling. If the proposed AI method fails, retain the simple comparison and test one different method. Do not expand into an untested drug-safety system.

