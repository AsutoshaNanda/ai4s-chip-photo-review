# Rules and dates

Verified from the [overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview) and [rules](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/rules) on 26 September 2026.

## Dates

| Stage | Published dates |
|---|---|
| Preliminary submissions | 15 August to 10 October 2026 |
| Submission cutoff shown by Kaggle | **10 October, 21:29:59 IST / 15:59:59 UTC** |
| Expert review | 10 to 20 October |
| Final presentations, 20 selected teams | 20 to 30 October |
| Results announcement | Before November 2026 |

About 14 days remain from 26 September. The rounded website countdown showed 15 days; use the exact cutoff above. Recheck before submitting.

## Required actions

- Complete the [separate registration form](https://docs.google.com/forms/d/e/1FAIpQLSdRAat5jIunRaFNh_NntsVeJUnekEJDrbuokLZ32LFgCwPtiA/viewform?usp=publish-editor). Kaggle entry alone is insufficient.
- Have 1 to 5 members and one leader. Each person joins only one team in this challenge.
- Declare one submission category at the start of the Writeup.
- Credit outside code, data, models, AI tools, and earlier work. Identify what we added.
- Use resources with suitable rights. Do not fabricate results or privately exchange core solutions between teams.
- Provide code that reviewers can run without paid services, special proprietary hardware, or non-public data.

## Read before sharing valuable work

The challenge rules state joint ownership of submitted materials by the team and organizing committee. They also preserve third-party rights and require separate written consent for listed commercial uses. Read the full terms; this guide does not resolve their legal effect.

Unresolved wording: team-formation cutoff, a bonus referring to a missing judging dimension, and some differences between the overview and rule sections. See [open questions](15_open_questions.md).

