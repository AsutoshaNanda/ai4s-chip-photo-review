# Experiments to run

**Status: all proposed; none run.** An experiment is one measured comparison.

## Set up a fair test first

- Use BBBC039's published splits. Training teaches the model; validation chooses settings; test is reserved for the final check.
- Keep every crop of an image in that image's split.
- Check for duplicate images and any overlap with pretrained-model training data.
- Save image IDs, settings, software versions, runtime, and predictions.
- Do not invent missing labels.

## Run in order

| ID | Question and comparison | Record | Decision |
|---|---|---|---|
| E0 | Do sample images match their reference outlines? | 20 training examples, loading errors, size checks | Fix mismatches before proceeding |
| E1 | How well does brightness thresholding plus watershed work? | Count error, object F1, runtime | Keep as the simple comparison |
| E2 | Does a small U-Net plus object separation beat E1? | Same validation images and measures | Keep only a useful, repeatable gain |
| E3 | Does teaching boundaries reduce merged nuclei? | E2 versus E2 with boundary training | Keep if crowded-image errors fall without large losses elsewhere |
| E4 | Do flips and rotations improve robustness? | E2 versus one changed training setup | Keep only if validation supports it |
| E5 | Can a warning identify bad counts? | Method disagreement versus a blur/brightness warning | Keep only if it catches more large errors at equal review workload |
| E6 | Does the selected approach survive a fresh run and final test? | Reloaded model; untouched test; second training seed if affordable | Report the result, including failures |

The order is a recommendation. Stop cosmetic tuning if the evidence favors a different method.

## Measurements in plain language

- **Count error:** Average absolute difference from the reference number of nuclei. Lower is better.
- **Object F1:** A score balancing missed nuclei and false detections. Higher is better. Match predictions to reference objects one-to-one using an overlap threshold fixed before testing.
- **IoU:** Shared mask area divided by combined mask area. Proposed matching threshold: 0.5. This is our evaluation choice, not the AI4S judging formula.
- **Runtime:** Seconds per image, with computer type recorded.

Show every method separately. Also show sparse/dense images, small/large nuclei, and the worst examples. Set group boundaries using training/validation data before final testing.

## Warning experiment details

Define a “large count error” and review budget using validation data first. Compare methods at the same percentage of flagged images. Report error on all images, errors among unflagged images, and how many bad cases were missed. Never hide hard images by dropping them.

## Extra test, only if time remains

Test on another real dataset after checking duplicates, rights, and model-training overlap. Report it separately. Artificial blur/brightness tests are useful stress tests, but cannot replace a real second dataset.

Record every result in [the experiment log](14_experiment_log.md). A failed final test means narrow the claim; it does not become a new tuning set.

