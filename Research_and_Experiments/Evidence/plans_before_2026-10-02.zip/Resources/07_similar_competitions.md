# Similar competitions and ideas to test

These are **outside evidence**. Their scores do not predict an AI4S result.

## 1. Data Science Bowl 2018: outline cell nuclei

The [dataset provider](https://bbbc.broadinstitute.org/BBBC038) describes images from varied biological and imaging conditions. The [organizer's analysis](https://github.com/carpenterlab/2019_caicedo_dsb) links these top three solutions:

| Place / author | What their public source shows | Small idea to test here |
|---|---|---|
| [1st: ods.ai topcoders](https://github.com/selimsef/dsb2018_topcoders) | Multiple model folders, neural and tree models, two-stage training | Preserve predictions from separate methods so errors can be compared |
| [2nd: Jacobkie](https://github.com/jacobkie/2018DSB) | Modified U-Net with eight position outputs; pretrained image features; predictions at four image scales | Test boundary-aware separation before attempting a full multi-scale system |
| [3rd: Deep Retina](https://github.com/Lopezurrutia/DSB_2018) | Mask R-CNN with pretrained image features, scaling, flips, and rotations | Test flips/rotations one change at a time |

The small ideas are our adaptations, not exact reproductions of the winning systems.

**Pitfall:** First-place instructions use CUDA 9 and cuDNN 7. These are historical setups, not current installation guidance. Do not run old scripts blindly.

## 2. Recursion / CellSignal 2019: distinguish biology from lab conditions

The [dataset owner's explanation](https://www.rxrx.ai/rxrx1) describes predicting genetic treatments on separate experimental batches.

**Apply here:** Where metadata permits, test on lab runs absent from training. For treatment tasks, report each cell type and batch separately.

**Reusable reference:** [Official starter code](https://github.com/recursionpharma/rxrx1-utils), especially image visualization. Its older training setup needs review.

## 3. Sartorius 2021: outline individual neuronal cells

[Official competition](https://www.kaggle.com/competitions/sartorius-cell-instance-segmentation/overview)

Phase-contrast images require separate outlines for irregular cells. Evaluation matches individual predicted objects to reference objects.

**Apply here:** Inspect merged and missed objects, not just whether foreground pixels look right. Use this as a method lesson; nucleus and whole-cell tasks are different.

## What to reuse first

Start with the [current watershed example](https://scikit-image.org/docs/stable/auto_examples/segmentation/plot_watershed.html) and [UNet4Nuclei reference](https://github.com/carpenterlab/unet4nuclei/). These are source-code starting points to inspect, not code verified to run in our environment.

Do not import past competition submission formats or leaderboard shortcuts into this hackathon.

