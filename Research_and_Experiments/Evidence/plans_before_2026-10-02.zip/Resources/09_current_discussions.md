# Current competition discussions

**Snapshot: 26 September 2026.** The live All view showed three threads on one page. These may change.

## 1. Clarification about Model & Algorithm submission.

[Thread](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/737840) · Manish Rathaur · one host reply.

**Verified host answer:** Real chip data is recommended, not mandatory. Public toxicity or cell-image datasets may be used with proper credit and rights. A method must explain its relevance to chip research.

**Action:** We can start with public images. Separate measured image-analysis performance from any proposed chip application.

## 2. Flaws in competition rules

[Thread](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/741126) · kelin hf · one host reply.

**Participant concern:** Lack of precise numerical judging standards.

**Host answer:** Projects vary, so one narrow metric is unsuitable; judging uses broader dimensions.

**Action:** Address all five published judging areas. Do not treat a notebook score or vote count as the winning target. The criticism is an opinion, not evidence of unfair judging.

## 3. [End-to-End System] HungDai AI BioLab: In Silico Fluorescence Translation & Neural Toxicity AI Suite for Organ-on-a-Chip

[Thread](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/741153) · Hung Dai Nguyen · no comments shown.

**Reported project:** Predict stained images, measure neural features, and estimate treatment response.

**Evidence limit:** The linked [notebook](https://www.kaggle.com/code/hungdainguyen/hungdai-ai-biolab-organ-on-chip) returned “We can't find that page.” Its reported scores were not independently reproduced.

**Action:** Learn from the input-to-output presentation structure. Do not adopt its accuracy, cost-saving, or biological claims as established facts.

## How to use this page later

Revisit the [discussion list](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion) before final submission. Record new host clarifications in [the decision log](13_evidence_and_decisions.md). No messages were posted during this research.

