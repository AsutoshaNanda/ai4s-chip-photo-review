# What data can we use?

**Verified:** There is no single required training dataset. The host confirms that real organ-on-a-chip data is encouraged but optional. [Host reply](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/737840)

## Resources named by the competition

Descriptions below are from its [Data section](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview#data). These are suggestions, not a verified download-and-license checklist.

| Resource | Plain meaning | Possible use |
|---|---|---|
| [CellNet](https://cellnet.hms.harvard.edu/) | Cell identity from gene measurements | A gene-data project |
| [BBBC](https://bbbc.broadinstitute.org/) | Biological images with reference answers | Image analysis |
| [IDR](https://idr.openmicroscopy.org/) | Images and details from published studies | Find a matching experiment |
| [RxRx1](https://www.rxrx.ai/rxrx1) | Cell images after genetic changes | Test across separate lab runs |
| [CytoData](https://www.cytodata.org/) | Community resources for measuring cell appearance | Tutorials and methods |
| [JUMP Hub](https://broadinstitute.github.io/jump_hub/) | Data guides and examples | Find usable tables |
| [JUMP-Cell Painting](https://jump-cellpainting.broadinstitute.org/) | Images after chemical or genetic changes | A larger follow-up project |

## Proposed first dataset: BBBC039

[Provider page](https://bbbc.broadinstitute.org/BBBC039)

- 200 microscope images of cell nuclei, with roughly 23,000 hand-drawn reference nuclei.
- TIFF images: 520 × 696 pixels, 16-bit.
- Downloads listed: images 77.9 MB; reference masks 2.8 MB; split metadata 18 KB.
- Published training, validation, and test lists are provided.
- Dataset license: CC0.
- Some images overlap BBBC038. Remove overlaps before calling BBBC038 an independent test.

**Why inspect it first:** Small download, real images, clear reference answers, and explicit rights. This is a proposed starting point, not proof that our model will work.

It supports nucleus outlining and counting. It does not by itself validate drug safety, whole-cell boundaries, or organ-on-a-chip performance.

## Alternatives, only if the project needs them

| Dataset | Verified facts | Decision |
|---|---|---|
| [BBBC021](https://bbbc.broadinstitute.org/BBBC021) | 13,200 three-channel views; 113 compounds; a smaller labeled subset; copyright attributed to AstraZeneca | More relevant to treatment appearance, but verify rights and scope first |
| [RxRx1](https://www.rxrx.ai/rxrx1) | Current downloads list 1 MB metadata, 51 MB image-feature table, and 45 GB images; CC BY-NC-SA 4.0 | Inspect the small table first; check non-commercial terms |
| [BBBC038](https://bbbc.broadinstitute.org/BBBC038) | Diverse nucleus images from the 2018 Data Science Bowl | Possible second test after overlap and rights checks |

**Before training:** Open sample image/mask pairs, verify counts and filenames, keep related images together, and save the exact split and source links. No dataset has been downloaded or selected irrevocably.

