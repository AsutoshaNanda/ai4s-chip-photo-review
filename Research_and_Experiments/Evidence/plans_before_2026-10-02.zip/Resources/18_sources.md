# Sources and verification

**Research date:** 26 September 2026, Asia/Kolkata.

## Competition sources

| Source | How checked | Used for |
|---|---|---|
| [Overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview) | Live signed-in browser | Categories, judging, data suggestions, exact cutoff, deliverables |
| [Rules](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/rules) | Live browser | Team, rights, external tools, and unresolved wording |
| [Discussion list](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion) | Live All view, one page | Three currently visible threads |
| [Code list](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/code) | Live All view | Four currently listed notebooks |
| [Notebook details](10_current_notebooks.md) | Rendered source and saved outputs | Methods, evidence limits, versions, displayed runtimes |
| [Pazhou organizer](https://www.aicompetition-pz.com/) | Official website | Event identity; site notes track schedules may differ |

Older search results showed fewer participants and submissions than the live page. Counts were not used to judge competitiveness.

## External sources

All links below were opened or returned as readable primary-source results:

- Data providers: [BBBC039](https://bbbc.broadinstitute.org/BBBC039), [BBBC038](https://bbbc.broadinstitute.org/BBBC038), [BBBC021](https://bbbc.broadinstitute.org/BBBC021), [BBBC041](https://bbbc.broadinstitute.org/BBBC041), [RxRx1](https://www.rxrx.ai/rxrx1), [JUMP Hub](https://broadinstitute.github.io/jump_hub/).
- Past work: [DSB organizer analysis](https://github.com/carpenterlab/2019_caicedo_dsb), [first-place source](https://github.com/selimsef/dsb2018_topcoders), [second-place source](https://github.com/jacobkie/2018DSB), [third-place source](https://github.com/Lopezurrutia/DSB_2018), [Recursion starter](https://github.com/recursionpharma/rxrx1-utils), [Sartorius overview](https://www.kaggle.com/competitions/sartorius-cell-instance-segmentation/overview).
- Learning: [Bioimage book](https://bioimagebook.github.io/), [CellProfiler](https://cellprofiler.org/examples), [watershed](https://scikit-image.org/docs/stable/auto_examples/segmentation/plot_watershed.html), [PyTorch](https://docs.pytorch.org/tutorials/beginner/basics/intro.html), [ZeroCostDL4Mic](https://henriqueslab.org/pages/zerocostdl4mic), [UNet4Nuclei](https://github.com/carpenterlab/unet4nuclei/).
- Tools and compute: [Cellpose](https://github.com/MouseLand/cellpose), [Kaggle notebooks](https://www.kaggle.com/docs/notebooks), [Kaggle GPU limits](https://www.kaggle.com/docs/efficient-gpu-usage), [Colab FAQ](https://research.google.com/colaboratory/intl/en-GB/faq.html).

## Limits of this research

- Reading code and saved output is not an independent rerun.
- Download links and advertised sizes were inspected; full data downloads were not tested.
- Resources listed only in the competition Data table are identified as such.
- The discussion-linked HungDai notebook returned a missing-page message.
- No score, free-resource allocation, future deadline stability, or winning chance is guaranteed.
- Schedule, project choice, and experiments are recommendations, not organizer requirements or established results.

Refresh the rules, deadline, discussions, code inventory, and compute terms before acting on a later date.

