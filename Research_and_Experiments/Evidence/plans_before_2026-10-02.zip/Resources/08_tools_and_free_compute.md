# Tools and free training resources

Checked 26 September 2026. **GPU** means a processor that can speed up AI training.

## Free compute

| Option | Verified offer | How we could use it |
|---|---|---|
| [Kaggle Notebooks](https://www.kaggle.com/docs/notebooks) | Free notebook compute and limited GPU access | Main training and shareable demonstration |
| [Kaggle GPU guidance](https://www.kaggle.com/docs/efficient-gpu-usage) | Weekly quota; documentation says 30 hours or sometimes higher | Check the account's actual remaining quota first |
| [Google Colab](https://research.google.com/colaboratory/intl/en-GB/faq.html) | Free compute, including possible GPU access; resources and limits are not guaranteed | Backup training notebook |
| Existing computer | No cloud allocation needed | Data checks, simple image methods, and report writing |

No guaranteed free A100, unlimited runtime, or account-specific quota has been verified.

**Proposed budget:** First run a tiny timing test. Budget one hour for the first training attempt, then estimate full cost from measured speed. Save progress and outputs regularly. Stop GPU sessions when doing non-training work.

## Useful tools

- [scikit-image](https://scikit-image.org/docs/stable/auto_examples/segmentation/plot_watershed.html): simple object-separation comparison.
- [CellProfiler](https://cellprofiler.org/examples): ready examples for measuring biological images.
- [PyTorch](https://docs.pytorch.org/tutorials/beginner/basics/intro.html): train and save the small AI model.
- [ZeroCostDL4Mic](https://henriqueslab.org/pages/zerocostdl4mic): beginner-friendly microscopy notebooks on Colab.

## Cellpose needs an extra check

The [current Cellpose repository](https://github.com/MouseLand/cellpose) documents version 4.2-era models and examples. Its software has a BSD license, but it also flags non-commercial training-data terms.

Do not assume the code license resolves rights for every model or dataset. Check the exact model and competition terms before selecting it. Also check whether its training images overlap our test. Our initial plan does not depend on it.

Use current documentation when implementing. Save the exact working package versions; do not upgrade halfway through final evaluation.

