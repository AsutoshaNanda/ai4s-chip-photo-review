# Submission checklist

Source: [official submission requirements](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview#submission-requirements), checked 26 September 2026.

## Required

- [ ] Required registration form completed; confirmation retained privately.
- [ ] Team details and eligibility checked.
- [ ] One category declared at the top of the Kaggle Writeup.
- [ ] Public video shows actual inputs, operation, and outputs.
- [ ] Video is at most 5 minutes; no login, payment, or access request needed.
- [ ] Public code link works.
- [ ] Code includes README, environment setup, data instructions, model files or download steps, and evaluation/demo entry points.
- [ ] Reviewers can reproduce the work without paid services, proprietary hardware, or non-public datasets.
- [ ] Technical report included directly or through a public PDF link.
- [ ] Data, models, libraries, AI tools, rights, and prior work disclosed.
- [ ] Results, failures, limits, and reproduction instructions included.

The organizer suggests a **200–300-word project summary** and a self-contained report ideally within **15–20 pages**, excluding references and appendices. These are recommendations, not a reason to pad the report.

## Our final checks

- [ ] Re-run from a clean setup.
- [ ] Every claimed number traces to saved results.
- [ ] Report each tested method, important group, and worst failure.
- [ ] Label synthetic, public microscopy, and real-chip evidence separately.
- [ ] Check links in a signed-out browser.
- [ ] If using an optional live demo, include a backup video and local run instructions.
- [ ] Record the final decision in [the evidence log](13_evidence_and_decisions.md).
- [ ] Confirm the Writeup is submitted, not merely saved as a draft.

**Internal target:** 9 October. **Official cutoff:** 10 October 2026, 9:29 PM IST.

