# Work schedule

**Proposed schedule, not a promise about available time or training speed.**

The official cutoff is **10 October 2026, 9:29 PM IST**. [Competition overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview)

| Date | Work | Must leave behind |
|---|---|---|
| 26 Sep | Read rules, check registration and data rights | One-page problem and source list |
| 27 Sep | Inspect images, masks, and official splits | Correct sample overlays and file list |
| 28 Sep | Build simple comparison and evaluator | E1 measurements |
| 29–30 Sep | Train one small AI model | E2 predictions, errors, and runtime |
| 1–2 Oct | Test at most two targeted changes | Keep/reject decisions with evidence |
| 3 Oct | Test review warnings and worst cases | E5 comparison and failure gallery |
| 4 Oct | Stop adding features; select method | Written selection reason |
| 5 Oct | Fresh run and untouched final test | Final results and saved model |
| 6 Oct | Build the smallest usable demo | Image-to-report workflow |
| 7 Oct | Reproduce from clean setup | Working instructions and dependencies |
| 8 Oct | Finish report and video | Complete submission draft |
| 9 Oct | Check access and submit | Confirmed submitted Writeup |
| 10 Oct | Buffer for verified fixes | Recheck status before cutoff |

## If behind

Drop optional extra datasets, large models, and cosmetic interface work first. Keep fair testing, honest limits, runnable code, and the required submission items.

If the AI model fails, report the negative result and assess whether a narrower tool remains useful. A simple method alone does not automatically establish an AI contribution.

If selected for finals, reserve 20–30 October for presentation and questions.

