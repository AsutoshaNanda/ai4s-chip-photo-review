# What is still unknown?

Checked 26 September 2026. These gaps are not assumptions.

| Question | Why it matters | Next action |
|---|---|---|
| What is the team-formation cutoff? | Rules mention it without a date in the reviewed text | Check host announcements or ask the host before changing a team |
| How does the +0.5 cross-disciplinary bonus apply? | Overview refers to “Interpretability and Reliability,” absent from the five listed judging dimensions | Request clarification; do not calculate a bonus ourselves |
| How should private-data projects meet public reproduction requirements? | Rules allow private data; overview requires reproduction without non-public data | Use fully public data for our initial plan |
| How do generic leaderboard rules apply to this judged hackathon? | Foundational text mentions test-set leaderboards; overview describes expert review | Follow the explicit Writeup deliverables and seek clarification if this affects a decision |
| Are registration and eligibility complete for this team? | Reading the page does not prove separate registration | Check the form confirmation and full rules |
| Can a particular pretrained model be used and redistributed? | Code, weights, and training data may have different terms | Check exact versions and resolve restrictions before reuse |
| Has a pretrained model seen our test images? | A familiar test can overstate quality | Inspect its data sources; disclose unresolved overlap |
| Will the proposed model and warnings help? | No local experiments exist | Run E0–E5 |
| How many free GPU hours are available to this account? | Provider limits vary | Check the current notebook quota |
| Does the tool solve a real user's problem? | A working demo alone does not establish impact | Seek feedback from a relevant researcher if available |

The registration-form page could not be read through the web research tool. Its mandatory status and link were verified on Kaggle.

These questions are documented for follow-up. No organizer messages were sent.

