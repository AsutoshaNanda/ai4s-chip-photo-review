# Original AI4S resources

All 19 original Markdown guides were moved here without changing their contents. Their relative links still work. The [manifest](../Research_and_Experiments/organization_manifest.json) records original filenames and SHA-256 checksums.

**For the updated research and experiment priorities, start with [Research and Experiments](../Research_and_Experiments/00_START_HERE.md).**

The older guides proposed nucleus counting first. New research found a public real organ-on-a-chip quality dataset, so the project choice has been reopened. The new collection records the data audit, license discrepancy, validation risks, and conditional alternatives.

The original [beginner-guide index](README.md) remains useful for background. Its project and schedule suggestions are historical proposals, not completed experiments or the latest selection decision.
