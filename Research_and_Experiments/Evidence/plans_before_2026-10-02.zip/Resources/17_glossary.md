# Small glossary

| Word | Simple meaning |
|---|---|
| Organ-on-a-chip / OoC | A small lab device that grows living cells under controlled conditions |
| Nucleus | The part of a cell that contains most of its DNA |
| Segmentation | Drawing separate regions around objects in an image |
| Mask | An image marking an object's pixels |
| Phenotype | A cell's observable appearance or behavior |
| Channel | One separately recorded image signal, often from one stain |
| Metadata | Details about a sample, such as its treatment or lab run |
| Baseline | A simple method used for comparison |
| Training | Teaching a model using examples |
| Validation | Checking examples used to choose model settings |
| Test set | Examples kept aside for the final check |
| Batch effect | A difference caused by lab conditions rather than the biology being studied |
| Leakage | Test information accidentally influencing training or model selection |
| Synthetic data | Artificial data made by a program |
| Pretrained model | A model already taught using another dataset |
| Fine-tuning | Further training an existing model |
| Ablation | Removing one component to test whether it helps |
| Reproducible | Someone else can follow the instructions and obtain comparable results |
| GPU / CPU | A training accelerator / a computer's general-purpose processor |
| U-Net | An AI model commonly used to label image pixels |
| Watershed | An image method that can split touching objects |
| Seed | A number that helps repeat a program's random choices |

