# Competition overview

Verified on 26 September 2026. [Official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview)

- **Task:** Build an AI project for life-science research.
- **Special interest:** Organ-on-a-chip, a small laboratory device that grows living cells under controlled conditions.
- **Choose one category:** Model & Algorithm, Tool & Platform, or End-to-End System.
- **Examples:** Analyze cell images, study treatment responses, or support research workflows.
- **Data:** Teams choose their own suitable, lawfully usable data.
- **Submission:** A Kaggle Writeup containing a public video, public code, and technical report.
- **Judging:** Experts review the project. The overview does not provide a shared prediction-file target.
- **Prizes:** Displayed total is $22,200. Awards are paid in CNY and subject to official announcements. No competition points or medals.

## What judges value

| Area | Weight | What we should show |
|---|---:|---|
| Importance and potential impact | 30% | A clear research problem and who benefits |
| Technical approach and innovation | 30% | A sound method and our actual contribution |
| Results and validation | 20% | Measured comparisons, including failures |
| Reproducibility and implementation | 10% | Someone else can run our work |
| Presentation | 10% | A clear working demonstration |

These weights are official. The suggested evidence in the last column is our proposed response.

**First decision:** Pick one narrow problem with accessible data. A complete, tested project is our goal; an award cannot be promised.

