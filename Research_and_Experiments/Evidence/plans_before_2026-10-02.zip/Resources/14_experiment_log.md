# Experiment log

**No experiments have been run. Blank means unmeasured, not zero.**

Copy this section for each run.

## Run ID: [fill after running]

| Field | Entry |
|---|---|
| Date and question | |
| Data source, version, and rights | |
| Training / validation / test IDs | |
| Method and exact change | |
| Code version and package versions | |
| Computer, runtime, and random seed | |
| Overall result | |
| Results per important group | |
| Worst failures | |
| Saved predictions, figures, and logs | |
| Evidence quality and limitations | |
| Hypothesis supported or rejected | |
| Decision: keep / reject / investigate | |
| Smallest next test | |

## Comparisons

| Run | Method | Count error | Object F1 | Worst group | Seconds/image | Decision |
|---|---|---|---|---|---|---|
| Not run | | | | | | |

Compare runs only when the data split and measurement definitions match. Record failed runs too. Never fill this table with another team's score.

