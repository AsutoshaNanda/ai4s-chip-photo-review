# Evidence and decisions

Research observations recorded on 26 September 2026. These are not model-test results.

| Observation | Evidence quality | What it supports or rejects | Decision and smallest next action |
|---|---|---|---|
| A video, code, and report are required | High: [official overview](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/overview) | Rejects a prediction-file-only plan | Reserve time for all three deliverables |
| Real chip data is optional | High: [host reply](https://www.kaggle.com/competitions/ai-4-s-open-innovation-artificial-intelligence-for-life-scien/discussion/737840) | Supports starting with public cell images | Inspect a small public dataset |
| BBBC039 has reference outlines and CC0 terms | High: [provider](https://bbbc.broadinstitute.org/BBBC039) | Supports a manageable image-analysis test | Open 20 training image/mask pairs |
| Some BBBC039 images overlap BBBC038 | High: [provider](https://bbbc.broadinstitute.org/BBBC039) | Rejects assuming those sets are independent | Audit overlap before an outside test |
| Several notebooks use simulated data | High for source contents; not proof of biological accuracy: [notebook review](10_current_notebooks.md) | Rejects treating their scores as real-chip evidence | Reuse only justified components; test independently |
| BioFluidNet scales all rows before splitting | High: inspected source, not rerun | Weakens confidence in the stated test | Move learned preprocessing inside each training split |
| Cellular Phenotyping uses saved predictions from BBBC041 | High for code; [dataset source](https://bbbc.broadinstitute.org/BBBC041) confirms blood smears | Does not support chip-monitoring claims | Require raw-data reproduction before adoption |
| Current Cellpose page flags non-commercial training data | High: [maintainer source](https://github.com/MouseLand/cellpose) | Rejects assuming unrestricted reuse | Resolve exact model rights or use our own small model |

## Rule for future results

For every important result, record observation, evidence quality, hypothesis supported/rejected, changed decision, and next test. Update immediately.

- If a stronger test contradicts the plan, pause that route and investigate.
- Confirm improvements with a fresh run or independent data.
- Keep a separately tested alternative if it survives different failures.
- Reject a method with catastrophic failures unless a tested fallback catches them.
- Never average away a failed group.

## Final selection, still pending

Chosen method: **not selected**.

Before submitting, link the decisive runs, worst cases, rights check, and reproduction check. Explain why the selected method follows the strongest evidence. If it does not, resolve the contradiction before proceeding.

