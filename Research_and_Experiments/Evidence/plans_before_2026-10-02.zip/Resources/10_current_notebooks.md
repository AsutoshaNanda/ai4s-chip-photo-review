# Current competition notebooks

**Snapshot: 26 September 2026.** The live Code list showed four notebooks. Source views and saved outputs were inspected; none was rerun. Displayed runtimes belong to those saved runs.

All four notebook pages displayed Apache 2.0 licensing. Check separate data, model, and linked-repository terms before reuse.

## 1. Biofluidnet V2 Ooc Physics Informed Deep Learning

[Lim Ba Su, version 5](https://www.kaggle.com/code/limbasu/biofluidnet-v2-ooc-physics-informed-deep-learning)

- **What it does:** Combines simulated chip flow, cell-feature tables, and treatment response.
- **Data:** Explicitly simulated. The notebook states its assumptions and limits.
- **Testing shown:** Excludes test compounds from training; separately tests unfamiliar flow settings and treatment mechanisms.
- **Useful parts:** Comparison tables, testing with components removed, saved results, and clear limits.
- **Limit:** Its model and simulator share mathematical structure. Success here does not establish real-chip accuracy.
- **Our action:** Borrow the evaluation organization. A simulation route would also need tests using a different simulator or real measurements.
- **Displayed run:** About 28 minutes on T4 GPU resources, not a runtime guarantee.

## 2. AI4S Organ-on-a-Chip Cellular Phenotyping

[Lio Kingo, version 2](https://www.kaggle.com/code/liokingo/ai4s-organ-on-a-chip-cellular-phenotyping)

- **What it does:** Loads saved model weights and predictions, then displays class scores and a map of image features.
- **Data named:** BBBC041. The [provider](https://bbbc.broadinstitute.org/BBBC041) identifies this as malaria-infected human blood smears.
- **Useful parts:** Per-class error tables and visual summaries.
- **Limit:** The displayed notebook does not recreate raw-image training. Blood-smear results do not validate chip monitoring.
- **Our action:** Reuse the reporting idea; verify original image splits and run predictions afresh before trusting model quality.
- **Displayed run:** About 76 seconds on CPU.

## 3. BioFluidNet-OoC: Multimodal Phenotypic Profiling

[Avik Das, version 2](https://www.kaggle.com/code/avikdas567/biofluidnet-ooc-multimodal-phenotypic-profiling)

- **What it does:** Generates synthetic treatment/flow data, compares models, and exports a prediction table.
- **Useful parts:** Basic comparison models, result exports, and workflow illustration.
- **Concrete concern:** Source fits input scaling on all rows before splitting. It uses one row-based split, which does not establish performance on unseen compounds.
- **Our action:** Fit learned preprocessing only on training data and keep entire compounds out of training for the test. Do not carry over published scores.
- **Submission reminder:** Its prediction CSV is an output example. AI4S requires the Writeup package.
- **Displayed run:** About 55 seconds on T4 GPU resources.

## 4. Neurochip Twin AI4S Reproducible Synthetic Demo

[Francisco Angulo de Lafuente, version 3](https://www.kaggle.com/code/franciscoangulo/neurochip-twin-ai4s-reproducible-synthetic-demo)

- **What it does:** Generates artificial image sequences, measures changes, compares prediction methods, and saves tables and a report.
- **Useful parts:** Small CPU demonstration, saved predictions, and explicit separation of synthetic and biological evidence.
- **Limit:** The displayed run is synthetic. The notebook says its separate BBBC038 check covers image segmentation only.
- **Our action:** Copy the reporting discipline, not its numerical results or biological interpretation. Any time-based model needs real sequences for real-world claims.
- **Displayed run:** About 58 seconds on CPU.

**Selection rule:** These are participant projects, not verified winning solutions. Use a component only when its purpose, license, inputs, and independent test are clear.

